package com.example.bakalarkacomplete;

public class ZnackyDatabaza {

    public static String[] vysNazov = {
            "Nebezpečenstvo", "Zákruta", "Dvojitá zákruta", "Klesanie", "Stúpanie", "Zúžená vozovka", "Svetelné signály", "Križovatka", "Chodci", "Deti", "Priechod pre chodcov", "Cyklisti", "Priecestie", "Návesť pred priecestím", "Výstražný kríž"
    };

    public static String[] vysPopis = {
            "Značka upozorňuje na iné nebezpečenstvo ako na to, na ktoré možno upozorniť vhodnou výstražnou značkou.", "Značka upozorňuje na nebezpečnú zákrutu vo vyznačenom smere, ktorej bezpečný prejazd si vyžaduje výrazné zníženie rýchlosti jazdy.",
            "Značka upozorňuje na dve alebo viac zákrut nasledujúcich bezprostredne za sebou vo vyznačenom smere, ktorých bezpečný prejazd si vyžaduje výrazné zníženie rýchlosti jazdy.",
            "Značka upozorňuje na nebezpečné klesanie.", "Značka upozorňuje na nebezpečné stúpanie.", "Značka upozorňuje na zúženú vozovku z vyznačenej strany alebo strán.", "Značka upozorňuje na riadenie cestnej premávky svetelnými signálmi.",
            "Značka upozorňuje na križovatku, kde nie je prednosť v jazde upravená dopravnými značkami a uplatňujú sa všeobecné pravidlá o prednosti v jazde.", "Značka upozorňuje na zvýšený pohyb chodcov na vozovke.",
            "Značka upozorňuje na zvýšený pohyb detí a zvýšené riziko ich neočakávaného vstupu do vozovky.", "Značka upozorňuje na priechod pre chodcov.", "Značka upozorňuje na zvýšený pohyb cyklistov alebo na miesto, kde cyklisti prechádzajú cez cestu alebo na ňu vchádzajú.",
            "Značka upozorňuje na priecestie.",  "Značka informuje o vzdialenosti k priecestiu. Značka s vyznačenými tromi pruhmi informuje o vzdialenosti 240 m k priecestiu, značka s dvoma pruhmi o vzdialenosti 160 m k priecestiu a značka s jedným pruhom o vzdialenosti 80 m k priecestiu.",
            "Značka označuje priecestie."
    };

    public static int[] vysObrazok = {
            R.drawable.vys01, R.drawable.vys02, R.drawable.vys03, R.drawable.vys04, R.drawable.vys05, R.drawable.vys06, R.drawable.vys07, R.drawable.vys08, R.drawable.vys09, R.drawable.vys10, R.drawable.vys11, R.drawable.vys12, R.drawable.vys13, R.drawable.vys14, R.drawable.vys15
    };

    public static String[] regNazov = {
            "Daj prednosť v jazde!", "Stoj, daj prednosť v jazde!", "Prednosť protiidúcich vozidiel", "Prikázaný smer jazdy", "Prikázaný smer odbočenia", "Prikázaný smer obchádzania", "Kruhový objazd", "Zákaz odbočenia", "Zákaz otáčania",
            "Cestička pre chodcov", "Cyklistická komunikácia", "Spoločná cestička pre chodcov a cyklistov", "Oddelená cestička pre chodcov a cyklistov", "Zákaz vjazdu", "Zákaz vjazdu pre všetky vozidlá", "Zákaz vjazdu (vstupu) pre cyklistov",
            "Najvyššia dovolená rýchlosť", "Koniec viacerých zákazov", "Zóna najvyššej dovolenej rýchlosti", "Koniec zóny najvyššej dovolenej rýchlosti", "Zákaz zastavenia", "Zákaz státia"
    };

    public static String[] regPopis = {
            "Značka ukladá vodičovi povinnosť dať prednosť v jazde.", "Značka ukladá vodičovi povinnosť zastaviť vozidlo a dať prednosť v jazde.", "Značka ukladá vodičovi povinnosť dať prednosť v jazde protiidúcim vozidlám.",
            "Značka prikazuje jazdu vo vyznačenom smere alebo vyznačených smeroch. Značky o smere jazdy neplatia pre električku a trolejbus.", "Značka prikazuje odbočenie vo vyznačenom smere. Značky o smere jazdy neplatia pre električku a trolejbus.",
            "Značka prikazuje obchádzanie vo vyznačenom smere. Značky o smere jazdy neplatia pre električku a trolejbus.", "Značka označuje kruhový objazd a prikazuje smer jazdy v smere vyznačenom šípkami na značke. Značky o smere jazdy neplatia pre električku a trolejbus.",
            "Značka zakazuje odbočenie vo vyznačenom smere. Značky o smere jazdy neplatia pre električku a trolejbus.", "Značka zakazuje otáčanie. Značky o smere jazdy neplatia pre električku a trolejbus.",
            "Značka označuje komunikáciu určenú pre chodcov a prikazuje chodcovi použiť takto označenú cestičku.", "Značka označuje cestičku pre cyklistov alebo cyklistický pruh a prikazuje cyklistovi použiť takto označenú cestičku alebo pruh.",
            "Značka označuje spoločnú komunikáciu určenú pre chodcov a cyklistov a prikazuje im ju použiť.", "Značka označuje oddelenú komunikáciu určenú pre chodcov a cyklistov a vyznačuje, ktorý pruh je určený pre chodcov a ktorý pruh je určený pre cyklistov; cyklistom a chodcom prikazuje použiť časť pre nich určenú.",
            "Značka zakazuje vjazd všetkými vozidlami. Značky o zákaze vjazdu neplatia pre električku a trolejbus.", "Značka zakazuje vjazd všetkými vozidlami v oboch smeroch jazdy. Značky o zákaze vjazdu neplatia pre električku a trolejbus.",
            "Značka zakazuje vjazd alebo vstup cyklistom alebo účastníkmi cestnej premávky vyznačeným symbolom. Značky o zákaze vjazdu neplatia pre električku a trolejbus.", "Značka zakazuje jazdiť rýchlosťou vyššou ako vyznačenou rýchlosťou v kilometroch za hodinu.",
            "Značka ukončuje zákazy vyplývajúce z iných zákazových značiek.", "Značka označuje začiatok zóny, v ktorej je zakázané jazdiť rýchlosťou vyššou ako vyznačenou rýchlosťou v kilometroch za hodinu.",
            "Značka označuje koniec zóny najvyššej dovolenej rýchlosti.", "Značka zakazuje zastavenie a státie. Zákaz platí aj na priľahlý chodník.", "Značka zakazuje státie. Zákaz platí aj na priľahlý chodník."
    };

    public static int[] regObrazok = {
            R.drawable.reg01, R.drawable.reg02, R.drawable.reg03, R.drawable.reg04, R.drawable.reg05, R.drawable.reg06, R.drawable.reg07, R.drawable.reg08, R.drawable.reg09, R.drawable.reg10, R.drawable.reg11,
            R.drawable.reg12, R.drawable.reg13, R.drawable.reg14, R.drawable.reg15, R.drawable.reg16, R.drawable.reg17, R.drawable.reg18, R.drawable.reg19, R.drawable.reg20, R.drawable.reg21, R.drawable.reg22
    };

    public static String[] infNazov = {
            "Križovatka s prednosťou v jazde", "Hlavná cesta", "Koniec hlavnej cesty", "Prednosť pred protiidúcimi vozidlami", "Obytná zóna", "Koniec obytnej zóny", "Pešia zóna", "Koniec pešej zóny", "Školská zóna", "Koniec školskej zóny",
            "Jednosmerná cesta", "Bicyklová cesta", "Koniec bicyklovej cesty", "Priechod pre chodcov", "Priechod pre cyklistov", "Slepá cesta", "Polícia", "Cyklistický smerník tabuľový", "Cyklistický smerník šípový",
            "Cyklistický medzismerník", "Číslo cyklotrasy", "Radenie do jazdných pruhov pred križovatkou"
    };

    public static String[] infPopis = {
            "Značka informuje o prednosti v jazde v najbližšej križovatke. Na značke môže byť znázornené aj len samostatné pravé pripojenie.", "Značka označuje začiatok alebo priebeh hlavnej cesty.",
            "Značka informuje o ukončení hlavnej cesty.", "Značka informuje vodiča o prednosti v jazde pred protiidúcimi vozidlami.", "Značka označuje miesto, od ktorého platia osobitné ustanovenia o cestnej premávke v obytnej zóne.",
            "Značka označuje koniec obytnej zóny.", "Značka označuje miesto, od ktorého platia osobitné ustanovenia o cestnej premávke v pešej zóne.", "Značka označuje koniec pešej zóny.",
            "Značka označuje miesto, od ktorého platia osobitné ustanovenia o cestnej premávke v školskej zóne.", "Značka označuje koniec školskej zóny.", "Značka označuje cestu s jednosmernou premávkou a vyznačuje dovolený smer jazdy.",
            "Značka označuje miesto, od ktorého platia osobitné ustanovenia o cestnej premávke na bicyklovej ceste.", "Značka označuje koniec bicyklovej cesty.", "Značka označuje priechod pre chodcov.",
            "Značka označuje priechod pre cyklistov.", "Značka označuje cestu, ktorá sa ďalej končí alebo ktorou nemožno ďalej pokračovať v jazde. Vhodným spôsobom možno informovať o prejazdnosti slepej cesty pre cyklistov.",
            "Značka informuje o blízkosti stanovišťa alebo útvaru Policajného zboru s nepretržitou službou.", "Značka informuje o smere jazdy k vyznačeným cieľom po cyklistickej trase a podľa potreby aj o vzdialenosti k týmto cieľom a o čísle alebo inom označení cyklotrasy. Ak sa na značke vyobrazujú turistické ciele, nápisy a symboly sú hnedej farby.",
            "Značka informuje o smere odbočenia k vyznačeným cieľom po cyklistickej trase a podľa potreby aj o vzdialenosti k týmto cieľom a o čísle alebo inom označení cyklotrasy. Ak sa na značke vyobrazujú turistické ciele, nápisy a symboly sú hnedej farby.",
            "Značka informuje o priebehu cyklotrasy cez križovatku.", "Značka v spojení s cyklistickým smerníkom informuje o čísle alebo inom označení cyklotrasy.",
            "Značka informuje na viacpruhovej ceste o potrebe včasného zaradenia sa do jazdných pruhov pred križovatkou podľa jednotlivých smerov jazdy tam, kde je usporiadanie radiacich pruhov v križovatke neobvyklé alebo inak neočakávateľné."
    };

    public static int[] infObrazok = {
            R.drawable.inf01, R.drawable.inf02, R.drawable.inf03, R.drawable.inf04, R.drawable.inf05, R.drawable.inf06, R.drawable.inf07, R.drawable.inf08, R.drawable.inf09, R.drawable.inf10, R.drawable.inf11,
            R.drawable.inf12, R.drawable.inf13, R.drawable.inf14, R.drawable.inf15, R.drawable.inf16, R.drawable.inf17, R.drawable.inf18, R.drawable.inf19, R.drawable.inf20, R.drawable.inf21, R.drawable.inf22
    };

    public static String[] dodNazov = {
            "Vzdialenosť", "Smerová šípka", "Smer platnosti", "Priebeh hlavnej cesty", "Vzdialenosť k povinnému zastaveniu", "Priečna jazda električky", "Priečna jazda cyklistov", "Obojsmerná jazda cyklistov", "Voľno"
    };

    public static String[] dodPopis = {
            "Dodatková tabuľka vyznačuje vzdialenosť k\n\na) nebezpečenstvu, na ktoré upozorňuje výstražná značka, pod ktorou je umiestnená,\nb) regulačnej značke, ktorou začína regulácia vyznačená regulačnou značkou, pod ktorou je umiestnená,\nc) miestu, o ktorom informuje informačná značka, pod ktorou je umiestnená.",
            "Dodatková tabuľka vyznačuje smer k\n\na) nebezpečenstvu, na ktoré upozorňuje výstražná značka, pod ktorou je umiestnená,\nb) regulačnej značke, ktorou sa začína regulácia vyznačená regulačnou značkou, pod ktorou je umiestnená,\nc) miestu, o ktorom informuje informačná značka, pod ktorou je umiestnená.",
            "Dodatková tabuľka vyznačuje smer platnosti dopravnej značky, pod ktorou je umiestnená. Dodatková tabuľka môže byť doplnená údajom o dĺžke platnosti daným smerom v metroch.",
            "Dodatková tabuľka umiestnená pod značkou Daj prednosť v jazde!, Stoj, daj prednosť v jazde! alebo Hlavná cesta vyznačuje priebeh hlavnej cesty, ak hlavná cesta vedie cez križovatku inak ako priamo alebo je jej priebeh ťažko rozoznateľný. Hlavná cesta je vyznačená hrubšou čiarou.",
            "Dodatková tabuľka umiestnená pod značkou Daj prednosť v jazde! vyznačuje vzdialenosť k značke Stoj, daj prednosť v jazde!.",
            "Dodatková tabuľka umiestnená pod značkou Daj prednosť v jazde! alebo Stoj, daj prednosť v jazde! ukladá vodičovi povinnosť dať prednosť v jazde a zároveň dať prednosť v jazde električke.",
            "Dodatková tabuľka umiestnená pod značkou Daj prednosť v jazde! alebo Stoj, daj prednosť v jazde! ukladá vodičovi povinnosť dať prednosť v jazde a zároveň dať prednosť v jazde cyklistom sprava aj zľava idúcim súbežne s cestou.",
            "Dodatková tabuľka umiestnená pod značkou Jednosmerná cesta umožňuje cyklistom jazdiť v oboch smeroch; vodič iného vozidla je povinný zvýšiť opatrnosť voči cyklistom v priebehu jednosmernej cesty.",
            "Dodatková tabuľka umiestnená pod značkou označujúcou špeciálnu cestičku alebo pruh umožňuje použiť špeciálnu cestičku alebo pruh vyznačeným účastníkom cestnej premávky, avšak neprikazuje im ju použiť."
    };

    public static int[] dodObrazok = {
            R.drawable.dod01, R.drawable.dod02, R.drawable.dod03, R.drawable.dod04, R.drawable.dod05, R.drawable.dod06, R.drawable.dod07, R.drawable.dod08, R.drawable.dod09
    };

    public static String[] vodNazov = {
            "STOP čiara", "Čakacia čiara", "Priechod pre chodcov", "Miesto na prechádzanie", "Priechod pre cyklistov", "Smerové šípky", "Koridor pre cyklistov"
    };

    public static String[] vodPopis = {
            "Značka vyznačuje miesto, kde je vodič povinný zastaviť na príkaz značky Stoj, daj prednosť v jazde! alebo pred križovatkou s riadenou premávkou. Značka môže byť doplnená nápisom STOP. Značkou možno vyznačiť predsunutý priestor určený pre cyklistov čakajúcich na svetelný signál zelenej farby, pričom cyklista je povinný zastaviť až pred vzdialenejšou čiarou.",
            "Značka vyznačuje miesto, kde sa vodičovi odporúča zastaviť vozidlo, ak dáva prednosť v jazde. Značka môže byť vyznačená aj prerušovanou čiarou tvorenou malými plnými trojuholníkmi vrcholmi orientovanými proti smeru jazdy.",
            "Značka vyznačuje priechod pre chodcov.", "Značka vyznačuje miesto prispôsobené na prechádzanie chodcov a cyklistov.", "Značka vyznačuje priechod pre cyklistov. Ak je priechod pre cyklistov primknutý k priechodu pre chodcov, vyznačuje sa len jednou čiarou.",
            "Smerové šípky vyznačené medzi pozdĺžnymi čiarami vyjadrujú spôsob radenia do jazdných pruhov a prikázaný smer jazdy cez nasledujúcu križovatku alebo odbočenie vo vyznačenom smere.",
            "Značka vyznačuje smer jazdy cyklistov."
    };

    public static int[] vodObrazok = {
            R.drawable.vod01, R.drawable.vod02, R.drawable.vod03, R.drawable.vod04, R.drawable.vod05, R.drawable.vod06, R.drawable.vod07
    };

    public static String[] sveNazov = {
            "„Stoj“ - signál červenej farby v tvare plného kruhu", "„Čakaj“ - signál žltej farby v tvare plného kruhu", "„Voľno“ - signál zelenej farby v tvare plného kruhu", "„Stoj“ - signál červenej farby so symbolom šípky",
            "„Čakaj“ - signál žltej farby so symbolom šípky", "„Voľno“ - signál v tvare zelenej šípky", "„Stoj“ - signál červenej farby so symbolom šípok", "„Čakaj“ - signál žltej farby so symbolom šípok",
            "„Voľno“ - signál v tvare zelených šípok", "„Stoj“ - signál pre cyklistov červenej farby v tvare bicykla", "„Čakaj“ - signál pre cyklistov žltej farby v tvare bicykla", "„Voľno“ - signál pre cyklistov zelenej farby v tvare bicykla",
            "„Stoj“ - signál červenej farby v tvare chodca a bicykla", "„Voľno“ - signál zelenej farby v tvare chodca a bicykla"
    };

    public static String[] svePopis = {
            "Pri riadení cestnej premávky v križovatke znamená pre vodiča, ak svieti signál červenej farby „Stoj“; vodič musí zastaviť pred križovatkou.",
            "Pri riadení cestnej premávky v križovatke znamená pre vodiča, ak svieti signál žltej farby „Čakaj“; pri rozsvietení tohto signálu počas rozsvieteného signálu červenej farby sa vodič musí pripraviť na jazdu a pri rozsvietení samostatného signálu žltej farby vodič musí zastaviť pred križovatkou, pričom ak je pri rozsvietení tohto signálu už tak blízko, že nemôže zastaviť bezpečne, smie pokračovať v jazde.",
            "Pri riadení cestnej premávky v križovatke znamená pre vodiča, ak svieti signál zelenej farby „Voľno“; vodič smie pokračovať v jazde pri dodržaní pravidiel cestnej premávky.",
            "Ak sú vodorovnými značkami vyznačené jazdné pruhy pre rôzne smery jazdy alebo skupiny smerov jazdy, môže byť cestná premávka v križovatke riadená samostatnými svetelnými signálmi so symbolom šípky alebo v tvare šípky pre každý z vyznačených smerov jazdy alebo skupín smerov jazdy osobitne. Ak svieti signál červenej alebo žltej farby so symbolom šípky alebo ak svieti signál v tvare zelenej šípky, ich význam („Stoj“, „Čakaj“, „Voľno“) platí len pre smer vyznačený šípkou.",
            "Ak sú vodorovnými značkami vyznačené jazdné pruhy pre rôzne smery jazdy alebo skupiny smerov jazdy, môže byť cestná premávka v križovatke riadená samostatnými svetelnými signálmi so symbolom šípky alebo v tvare šípky pre každý z vyznačených smerov jazdy alebo skupín smerov jazdy osobitne. Ak svieti signál červenej alebo žltej farby so symbolom šípky alebo ak svieti signál v tvare zelenej šípky, ich význam („Stoj“, „Čakaj“, „Voľno“) platí len pre smer vyznačený šípkou.",
            "Ak sú vodorovnými značkami vyznačené jazdné pruhy pre rôzne smery jazdy alebo skupiny smerov jazdy, môže byť cestná premávka v križovatke riadená samostatnými svetelnými signálmi so symbolom šípky alebo v tvare šípky pre každý z vyznačených smerov jazdy alebo skupín smerov jazdy osobitne. Ak svieti signál červenej alebo žltej farby so symbolom šípky alebo ak svieti signál v tvare zelenej šípky, ich význam („Stoj“, „Čakaj“, „Voľno“) platí len pre smer vyznačený šípkou.",
            "Ak sú vodorovnými značkami vyznačené jazdné pruhy pre rôzne smery jazdy alebo skupiny smerov jazdy, môže byť cestná premávka v križovatke riadená samostatnými svetelnými signálmi so symbolom šípky alebo v tvare šípky pre každý z vyznačených smerov jazdy alebo skupín smerov jazdy osobitne. Ak svieti signál červenej alebo žltej farby so symbolom šípky alebo ak svieti signál v tvare zelenej šípky, ich význam („Stoj“, „Čakaj“, „Voľno“) platí len pre smer vyznačený šípkou.",
            "Ak sú vodorovnými značkami vyznačené jazdné pruhy pre rôzne smery jazdy alebo skupiny smerov jazdy, môže byť cestná premávka v križovatke riadená samostatnými svetelnými signálmi so symbolom šípky alebo v tvare šípky pre každý z vyznačených smerov jazdy alebo skupín smerov jazdy osobitne. Ak svieti signál červenej alebo žltej farby so symbolom šípky alebo ak svieti signál v tvare zelenej šípky, ich význam („Stoj“, „Čakaj“, „Voľno“) platí len pre smer vyznačený šípkou.",
            "Ak sú vodorovnými značkami vyznačené jazdné pruhy pre rôzne smery jazdy alebo skupiny smerov jazdy, môže byť cestná premávka v križovatke riadená samostatnými svetelnými signálmi so symbolom šípky alebo v tvare šípky pre každý z vyznačených smerov jazdy alebo skupín smerov jazdy osobitne. Ak svieti signál červenej alebo žltej farby so symbolom šípky alebo ak svieti signál v tvare zelenej šípky, ich význam („Stoj“, „Čakaj“, „Voľno“) platí len pre smer vyznačený šípkou.",
            "Na riadenie cestnej premávky cyklistov v križovatke možno použiť svetelné signály v tvare bicykla.", "Na riadenie cestnej premávky cyklistov v križovatke možno použiť svetelné signály v tvare bicykla.",
            "Na riadenie cestnej premávky cyklistov v križovatke možno použiť svetelné signály v tvare bicykla.", "Na riadenie cestnej premávky cyklistov, ktorá je cez vozovku vedená súbežne s premávkou chodcov, možno použiť svetelné signály v tvare chodca a bicykla.",
            "Na riadenie cestnej premávky cyklistov, ktorá je cez vozovku vedená súbežne s premávkou chodcov, možno použiť svetelné signály v tvare chodca a bicykla."
    };

    public static int[] sveObrazok = {
            R.drawable.sve01, R.drawable.sve02, R.drawable.sve03, R.drawable.sve04, R.drawable.sve05, R.drawable.sve06, R.drawable.sve07,
            R.drawable.sve08, R.drawable.sve09, R.drawable.sve10, R.drawable.sve11, R.drawable.sve12, R.drawable.sve13, R.drawable.sve14
    };

    public static String[] pokNazov = {
            "Pokyn - „Stoj“", "Pokyn - „Čakaj“", "Pokyn - „Voľno“", "Pokyn - „Stoj“ a „Voľno“", "Pokyn - Zrýchliť jazdu!", "Pokyn - Spomaliť jazdu!"
    };

    public static String[] pokPopis = {
            "Pokyny policajta znamenajú pre účastníkov cestnej premávky „Stoj“ pre smer, ku ktorému stojí policajt čelom alebo chrbtom s upaženou rukou alebo upaženými rukami; policajt môže obe ruky pripažiť, ak na riadenie cestnej premávky stačí postoj.",
            "Pokyny policajta znamenajú pre účastníkov cestnej premávky „Čakaj“, ak má policajt zdvihnutú pravú ruku alebo predlaktie pravej ruky nahor; pre účastníkov cestnej premávky už sa nachádzajúcich v križovatke znamená tento pokyn „Opustite križovatku“.",
            "Pokyny policajta znamenajú pre účastníkov cestnej premávky „Voľno“ pre smer, ku ktorému stojí policajt bokom s upaženou rukou alebo upaženými rukami; policajt môže obe ruky pripažiť, ak na riadenie cestnej premávky stačí postoj.",
            "Pokyny policajta znamenajú pre účastníkov cestnej premávky „Stoj“ pre vodiča prichádzajúceho smerom k chrbtu alebo k pravému boku policajta, ak má policajt pravú ruku predpaženú a ľavú ruku upaženú a „Voľno“ pre vodiča prichádzajúceho smerom k ľavému boku policajta; vodič vozidla prichádzajúceho smerom k čelu policajta môže odbočiť vpravo a chodci smú prechádzať cez vozovku za chrbtom policajta.",
            "Policajt môže pri riadení cestnej premávky dávať okrem pokynov uvedených v predošlých bodoch aj iné pokyny, najmä pokyn „Zrýchliť jazdu!“ vodorovným kývaním ruky cez stred tela. Na zdôraznenie pokynu môže policajt použiť píšťalku.",
            "Policajt môže pri riadení cestnej premávky dávať okrem pokynov uvedených v predošlých bodoch aj iné pokyny, najmä pokyn „Spomaliť jazdu!“ kývaním ruky hore a dolu. Na zdôraznenie pokynu môže policajt použiť píšťalku."
    };

    public static int[] pokObrazok = {
            R.drawable.pok01, R.drawable.pok02, R.drawable.pok03, R.drawable.pok04, R.drawable.pok05, R.drawable.pok06
    };

    public static String[] symNazov = {
            "Bicykle", "Chodci", "Deti", "Elektrobicykle", "Malé elektrické vozidlá", "Osoby pohybujúce sa na korčuliach, skejtborde, kolobežke alebo na obdobnom športovom vybavení", "Nemocnica", "Prvá pomoc"
    };

    public static String[] symPopis = {
            "Nemotorové vozidlá poháňané ľudskou silou vyvíjanou pomocou pedálov alebo ručných kľúk.", "", "", "Bicykle s elektrickým pomocným pohonom, ktorého výkon sa preruší, keď bicykel dosiahne rýchlosť 25 km/h.",
            "Kolobežky s pomocným motorčekom, samovyvažovacie vozidlá a iné dopravné prostriedky s elektrickým pohonom na individuálne presuny.", "Osoby pohybujúce sa na korčuliach, skejtborde, kolobežke alebo na obdobnom športovom vybavení.",
            "", ""
    };

    public static int[] symObrazok = {
            R.drawable.sym01, R.drawable.sym02, R.drawable.sym03, R.drawable.sym04, R.drawable.sym05, R.drawable.sym06, R.drawable.sym07, R.drawable.sym08
    };

}

// databáza pre aktivitu Značky ... obsahuje rozdelenie značiek na 8 skupín ... každá značka v danej skupine obsahuje názov, obrázok značky a stručný popis

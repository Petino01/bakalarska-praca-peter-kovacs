package com.example.bakalarkacomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.Arrays;
import java.util.Collections;

public class PribehTest extends AppCompatActivity implements View.OnClickListener {

    TextView pribehText, cisloOtazkyText;
    Button odpA, odpB, odpC;
    Button odoslatB;
    VideoView krizovatka;

    int cisloOtazky;
    String vybranaOdpoved;

    Integer[] poradie = {1, 2, 3, 4, 5, 6}; // poradie úloh v príbehu
    Integer[] poradieOdpovedi = {0, 1, 2}; // poradie zobrazenie odpovedí k daným úlohám

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pribeh_test);

        pribehText = findViewById(R.id.pribehText);
        odpA = findViewById(R.id.odpA);
        odpB = findViewById(R.id.odpB);
        odpC = findViewById(R.id.odpC);
        odoslatB = findViewById(R.id.odoslat);
        krizovatka = findViewById(R.id.krizovatkaVideo);

        pribehText.setMovementMethod(new ScrollingMovementMethod()); // zabezpečenie scrollovania textu v TextView

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            pribehText.setTextSize(18);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            pribehText.setTextSize(21);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            pribehText.setTextSize(24);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            pribehText.setTextSize(27);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            pribehText.setTextSize(30);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            pribehText.setTextSize(33);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            pribehText.setTextSize(36);
        }

        cisloOtazkyText = findViewById(R.id.cisloOtazky);

        odoslatB.setBackgroundColor(Color.rgb(185,85,255));

        odpA.setOnClickListener(this);
        odpB.setOnClickListener(this);
        odpC.setOnClickListener(this);
        odoslatB.setOnClickListener(this);

        odoslatB.setVisibility(View.GONE);

        nacitajNovuOtazku(); // zavolanie metódy pre načítanie prvej otázky (úlohy)

        cisloOtazky = 0;
        vybranaOdpoved = "";

        krizovatka.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                krizovatka.pause();
                nacitajNovuOtazku(); // po skončení videa sa videoView pozastaví a zavolá sa metóda na načítanie ďaľšej otázky
            }
        });

        Collections.shuffle(Arrays.asList(poradie)); // pri vytvorení aktivity sa zamieša poradie úloh, čo by malo zabezpečiť, že sa rovnaké poradie neudeje dvakrát alebo viackrát po sebe
    }

    @Override
    public void onClick(View view) {
        odpA.setBackgroundColor(Color.rgb(235,236,240));
        odpB.setBackgroundColor(Color.rgb(235,236,240));
        odpC.setBackgroundColor(Color.rgb(235,236,240));
        odoslatB.setVisibility(View.VISIBLE);

        Button kliknutie = (Button) view; // vytvoríme onClick pre Button
        if(kliknutie.getId() == R.id.odoslat) { // ak sa klikne na tlačidlo Potvrdiť vykoná sa nasledovné
            odoslatB.setVisibility(View.GONE); // tlačidlo Potvrdiť zmizne
            if(!vybranaOdpoved.equals("")) { // ak sa vybraná odpoveď nerovná prázdnemu Stringu
                if(cisloOtazky == 0 && vybranaOdpoved.equals(OtazkyOdpovedePribeh.spravneOdpovede[0])) { // ak sa jedná o prvú úlohu v príbehu a vybraná odpoveď sa rovná správnej odpovedi vykoná sa nasledovné
                    cisloOtazky++; // zvýši sa číslo otázky
                    krizovatka.start(); // videoView s videom križovatky sa spustí
                    vybranaOdpoved = ""; // vybraná odpoveď sa nastaví na prázdny String

                    odpA.setEnabled(false);
                    odpB.setEnabled(false);
                    odpC.setEnabled(false);
                    odoslatB.setEnabled(false); // tlačidlá sa deaktivujú a po dobu prehrávania videa sa nebude dať klikať na ne
                } else if(cisloOtazky != 0 && vybranaOdpoved.equals(OtazkyOdpovedePribeh.spravneOdpovede[poradie[cisloOtazky - 1]])){ // ak sa nejedná o prvú úlohu a vybraná odpoveď sa rovná správnej odpovedi vykoná sa nasledovné
                    cisloOtazky++; // zvýši sa číslo otázky
                    krizovatka.start(); // videoView s videom križovatky sa spustí
                    vybranaOdpoved = ""; // vybraná odpoveď sa nastaví na prázdny String

                    odpA.setEnabled(false);
                    odpB.setEnabled(false);
                    odpC.setEnabled(false);
                    odoslatB.setEnabled(false); // tlačidlá sa deaktivujú a po dobu prehrávania videa sa nebude dať klikať na ne
                } else { // ak sa vybraná odpoveď nerovná správnej odpovedi vykoná sa nasledovné
                    neuspesnyAlert(); // zavolá sa metóda na vytvorenie neúspešného alertu
                }
            }
        } else { // ak sa nejedná o kliknutie na tlačidlo Potvrdiť, zapíše sa vybraná odpoveď používateľom z jednej z troch poskytnutých možností
            vybranaOdpoved = kliknutie.getText().toString();
            kliknutie.setBackgroundColor(Color.rgb(185,85,255));
        }
    }

    void nacitajNovuOtazku() { // metóda pre načítanie ďaľšej otázky (úlohy)
        odpA.setEnabled(true);
        odpB.setEnabled(true);
        odpC.setEnabled(true);
        odoslatB.setEnabled(true);

        odoslatB.setVisibility(View.GONE);

        cisloOtazkyText.setText("Situácia č. " + (cisloOtazky + 1) + " zo 7");

        Collections.shuffle(Arrays.asList(poradieOdpovedi)); // poradie zobrazenia odpovedí sa zamieša pri každom načítaní novej otázky (úlohy)

        if(cisloOtazky == 7) { // ak sa číslo otázky rovná hodnote 7 vykoná sa nasledovné
            ukonciTest(); // zavolá sa metóda pre ukončenie testu
            cisloOtazkyText.setVisibility(View.GONE);
            pribehText.setVisibility(View.GONE);
            odpA.setVisibility(View.GONE);
            odpB.setVisibility(View.GONE);
            odpC.setVisibility(View.GONE);
            krizovatka.setVisibility(View.GONE); // všetky objekty v layoute sa nastavia na neviditeľné
            return; // ukončí sa celá metóda
        }

        if(cisloOtazky == 0) { // ak sa číslo otázky rovná hodnote 0, to znamená že sa jedná o prvú otázku (úlohu), daná úloha je vždy rovnaká (začiatok príbehu)
            pribehText.setText(OtazkyOdpovedePribeh.pribehText[0]); // nastaví sa úvodný text príbehu na indexe 0
            odpA.setText(OtazkyOdpovedePribeh.odpovede[0][poradieOdpovedi[0]]); // nastaví sa odpoveď A na indexe 0
            odpB.setText(OtazkyOdpovedePribeh.odpovede[0][poradieOdpovedi[1]]); // nastaví sa odpoveď B na indexe 0
            odpC.setText(OtazkyOdpovedePribeh.odpovede[0][poradieOdpovedi[2]]); // nastaví sa odpoveď C na indexe 0
            String videoCesta = "android.resource://" + getPackageName() + "/" + OtazkyOdpovedePribeh.videa[0];
            Uri uri = Uri.parse(videoCesta);
            krizovatka.setVideoURI(uri); // nastaví sa video na indexe 0
            krizovatka.seekTo(1); // video sa presunie na prvý frame
            pribehText.scrollTo(0,0); // pomocou scrollTo(0,0) sa aj scrollnutý text vždy presunie na úplný začiatok
        } else {
            pribehText.setText(OtazkyOdpovedePribeh.pribehText[poradie[cisloOtazky - 1]]); // nastaví sa text príbehu na danom indexe
            odpA.setText(OtazkyOdpovedePribeh.odpovede[poradie[cisloOtazky - 1]][poradieOdpovedi[0]]); // nastaví sa odpoveď A na danom indexe
            odpB.setText(OtazkyOdpovedePribeh.odpovede[poradie[cisloOtazky - 1]][poradieOdpovedi[1]]); // nastaví sa odpoveď A na danom indexe
            odpC.setText(OtazkyOdpovedePribeh.odpovede[poradie[cisloOtazky - 1]][poradieOdpovedi[2]]); // nastaví sa odpoveď A na danom indexe
            String videoCesta = "android.resource://" + getPackageName() + "/" + OtazkyOdpovedePribeh.videa[poradie[cisloOtazky - 1]];
            Uri uri = Uri.parse(videoCesta);
            krizovatka.setVideoURI(uri); // nastaví sa video na danom indexe
            krizovatka.seekTo(1); // video sa presunie na prvý frame
            pribehText.scrollTo(0,0); // pomocou scrollTo(0,0) sa aj scrollnutý text vždy presunie na úplný začiatok
        }
    }

    void ukonciTest() { // metóda pre ukončenie (úspešné) príbehu
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(PribehTest.this, R.style.AlertDialogStyle); // zobrazí sa Alert Dialog so správou, že používateľ úspešne zvládol príbeh a môže sa vrátiť do hlavného menu
                alertDialogBuilder.setTitle("Úspešné ukončenie príbehu!")
                .setMessage("Odpovedal si správne na všetky dopravné situácie a žiačik sa úspešne dostal domov!")
                .setNeutralButton("Hlavné menu", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(PribehTest.this, HlavneMenu.class);
                        startActivity(intent);
                        finish(); // po zvolení možnosti Hlavné menu sa pomocou nového Intentu používateľ presunie do Hlavného menu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.setCancelable(false);
                alertDialog.show();
                alertDialog.getButton(alertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(187,134,252));
    }

    void neuspesnyAlert() { // metóda pre ukončenie (neúspešné) príbehu
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(PribehTest.this, R.style.AlertDialogStyle); // zobrazí sa Alert Dialog so správou, že používateľ nezvládol úspešne dokončiť príbeh a môže to skúsiť znova alebo sa vrátiť do hlavného menu
                alertDialogBuilder.setTitle("Neúspešná odpoveď!")
                .setMessage("Tvoja odpoveď bola zlá a tým pádom sa musíš vrátiť na začiatok alebo do hlavného menu.")
                .setPositiveButton("Skúsiť ešte raz", ((dialogInterface, i) -> resetniQuiz())) // po zvolení možnosti Skúsiť ešte raz sa Alert Dialog zatvorí a zavolá sa metóda resetniQuiz()
                .setNegativeButton("Hlavné menu", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(PribehTest.this, HlavneMenu.class);
                        startActivity(intent);
                        finish(); // po zvolení možnosti Hlavné menu sa pomocou nového Intentu používateľ presunie do Hlavného menu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.setCancelable(false);
                alertDialog.show();
                alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(65,200,0));
                alertDialog.getButton(alertDialog.BUTTON_NEGATIVE).setTextColor(Color.rgb(225,15,15));
    }

    // pri nesprávnej odpovedi aj v poslednej otázke (úlohe) sa používateľ vracia na začiatok ... keďže sa jedná o reálne situácie, v ktorých by sa mohol používateľ objaviť, je potrebné dbať na bezchybnosť a preto som zvolil takýto typ penalizovania za nesprávnu odpoveď
    void resetniQuiz() { // metóda na resetovanie príbehu
        cisloOtazky = 0; // číslo otázky sa nastaví na nulovú hodnotu
        vybranaOdpoved = ""; // vybraná odpoveď sa nastaví na prázdny String
        nacitajNovuOtazku(); // zavolá sa metóda na načítanie ďaľšej otázky (úlohy)
    }
}
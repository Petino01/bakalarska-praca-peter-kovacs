package com.example.bakalarkacomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TestyPrehlad extends AppCompatActivity {

    TextView nOdpoved1, nOdpoved2, nOdpoved3, nOdpoved4, nOdpoved5, nOdpoved6 , nOdpoved7, nOdpoved8, nOdpoved9, nOdpoved10;
    TextView sOdpoved1, sOdpoved2, sOdpoved3, sOdpoved4, sOdpoved5, sOdpoved6, sOdpoved7, sOdpoved8, sOdpoved9, sOdpoved10;
    TextView otazka1, otazka2, otazka3, otazka4, otazka5, otazka6, otazka7, otazka8, otazka9, otazka10;
    ImageView obrazok1, obrazok2, obrazok3, obrazok4, obrazok5;

    Button ukonceniePrehladu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testy_prehlad);

        // získanie údajov z predošlej aktivity Testy ... nachádza sa tu ArrayList obsahujúci nesprávne odpovede, správne odpovede, otázky a obrázky
        Bundle extras = getIntent().getExtras();
        ArrayList<String> nespravneOdpovede = new ArrayList<String>();
        nespravneOdpovede = extras.getStringArrayList("nespravneOdpovede");
        ArrayList<String> spravneOdpovede = new ArrayList<String>();
        spravneOdpovede = extras.getStringArrayList("spravneOdpovede");
        ArrayList<String> otazky = new ArrayList<String>();
        otazky = extras.getStringArrayList("otazky");
        ArrayList<Integer> obrazky = new ArrayList<Integer>();
        obrazky = extras.getIntegerArrayList("obrazky");

        // pole intov s odkazmi na Textview nesprávnych odpovedí, správnych odpovedí a otázok v layoute
        int[] nespravnaOdpoved = {R.id.nespravnaOdpoved1, R.id.nespravnaOdpoved2, R.id.nespravnaOdpoved3, R.id.nespravnaOdpoved4, R.id.nespravnaOdpoved5, R.id.nespravnaOdpoved6, R.id.nespravnaOdpoved7, R.id.nespravnaOdpoved8, R.id.nespravnaOdpoved9, R.id.nespravnaOdpoved10};
        int[] spravnaOdpoved = {R.id.spravnaOdpoved1, R.id.spravnaOdpoved2, R.id.spravnaOdpoved3, R.id.spravnaOdpoved4, R.id.spravnaOdpoved5, R.id.spravnaOdpoved6, R.id.spravnaOdpoved7, R.id.spravnaOdpoved8, R.id.spravnaOdpoved9, R.id.spravnaOdpoved10};
        int[] otazka = {R.id.otazka1, R.id.otazka2, R.id.otazka3, R.id.otazka4, R.id.otazka5, R.id.otazka6, R.id.otazka7, R.id.otazka8, R.id.otazka9, R.id.otazka10};

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            for(int id: otazka) { // pomocou for cyklov priradíme všetkým otázkam, nesprávnym odpovediam a správnym odpovediam príslušnú veľkosť pre danú veľkosť obrazovky
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(18);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(16);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(16);
            }
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            for(int id: otazka) {
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(21);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(19);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(19);
            }
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            for(int id: otazka) {
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(24);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(22);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(22);
            }
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            for(int id: otazka) {
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(27);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(25);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(25);
            }
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            for(int id: otazka) {
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(30);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(28);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(28);
            }
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            for(int id: otazka) {
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(33);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(31);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(31);
            }
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            for(int id: otazka) {
                TextView otazkaOtazka = (TextView) findViewById(id);
                otazkaOtazka.setTextSize(36);
            }
            for(int id: nespravnaOdpoved) {
                TextView nesOdpoved = (TextView) findViewById(id);
                nesOdpoved.setTextSize(34);
            }
            for(int id: spravnaOdpoved) {
                TextView sOdpoved = (TextView) findViewById(id);
                sOdpoved.setTextSize(34);
            }
        }

        otazka1 = findViewById(R.id.otazka1);
        otazka2 = findViewById(R.id.otazka2);
        otazka3 = findViewById(R.id.otazka3);
        otazka4 = findViewById(R.id.otazka4);
        otazka5 = findViewById(R.id.otazka5);
        otazka6 = findViewById(R.id.otazka6);
        otazka7 = findViewById(R.id.otazka7);
        otazka8 = findViewById(R.id.otazka8);
        otazka9 = findViewById(R.id.otazka9);
        otazka10 = findViewById(R.id.otazka10);

        nOdpoved1 = findViewById(R.id.nespravnaOdpoved1);
        nOdpoved2 = findViewById(R.id.nespravnaOdpoved2);
        nOdpoved3 = findViewById(R.id.nespravnaOdpoved3);
        nOdpoved4 = findViewById(R.id.nespravnaOdpoved4);
        nOdpoved5 = findViewById(R.id.nespravnaOdpoved5);
        nOdpoved6 = findViewById(R.id.nespravnaOdpoved6);
        nOdpoved7 = findViewById(R.id.nespravnaOdpoved7);
        nOdpoved8 = findViewById(R.id.nespravnaOdpoved8);
        nOdpoved9 = findViewById(R.id.nespravnaOdpoved9);
        nOdpoved10 = findViewById(R.id.nespravnaOdpoved10);

        sOdpoved1 = findViewById(R.id.spravnaOdpoved1);
        sOdpoved2 = findViewById(R.id.spravnaOdpoved2);
        sOdpoved3 = findViewById(R.id.spravnaOdpoved3);
        sOdpoved4 = findViewById(R.id.spravnaOdpoved4);
        sOdpoved5 = findViewById(R.id.spravnaOdpoved5);
        sOdpoved6 = findViewById(R.id.spravnaOdpoved6);
        sOdpoved7 = findViewById(R.id.spravnaOdpoved7);
        sOdpoved8 = findViewById(R.id.spravnaOdpoved8);
        sOdpoved9 = findViewById(R.id.spravnaOdpoved9);
        sOdpoved10 = findViewById(R.id.spravnaOdpoved10);

        obrazok1 = findViewById(R.id.obrazok1);
        obrazok2 = findViewById(R.id.obrazok2);
        obrazok3 = findViewById(R.id.obrazok3);
        obrazok4 = findViewById(R.id.obrazok4);
        obrazok5 = findViewById(R.id.obrazok5);

        otazka1.setText("1. " + otazky.get(0)); // vložíme otázky z ArrayListu obsahujúceho otázky zo splneného testu
        otazka2.setText("2. " + otazky.get(1));
        otazka3.setText("3. " + otazky.get(2));
        otazka4.setText("4. " + otazky.get(3));
        otazka5.setText("5. " + otazky.get(4));
        otazka6.setText("6. " + otazky.get(5));
        otazka7.setText("7. " + otazky.get(6));
        otazka8.setText("8. " + otazky.get(7));
        otazka9.setText("9. " + otazky.get(8));
        otazka10.setText("10. " + otazky.get(9));

        nOdpoved1.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(0)); // vložíme nesprávne odpovede z ArrayListu obsahujúceho nesprávne odpovede zo splneného testu ak nejaké boli
        nOdpoved2.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(1));
        nOdpoved3.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(2));
        nOdpoved4.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(3));
        nOdpoved5.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(4));
        nOdpoved6.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(5));
        nOdpoved7.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(6));
        nOdpoved8.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(7));
        nOdpoved9.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(8));
        nOdpoved10.setText("Nesprávna odpoveď: " + nespravneOdpovede.get(9));

        sOdpoved1.setText("Správna odpoveď: " + spravneOdpovede.get(0)); // vložíme správne odpovede z ArrayListu obsahujúceho správne odpovede zo splneného testu
        sOdpoved2.setText("Správna odpoveď: " + spravneOdpovede.get(1));
        sOdpoved3.setText("Správna odpoveď: " + spravneOdpovede.get(2));
        sOdpoved4.setText("Správna odpoveď: " + spravneOdpovede.get(3));
        sOdpoved5.setText("Správna odpoveď: " + spravneOdpovede.get(4));
        sOdpoved6.setText("Správna odpoveď: " + spravneOdpovede.get(5));
        sOdpoved7.setText("Správna odpoveď: " + spravneOdpovede.get(6));
        sOdpoved8.setText("Správna odpoveď: " + spravneOdpovede.get(7));
        sOdpoved9.setText("Správna odpoveď: " + spravneOdpovede.get(8));
        sOdpoved10.setText("Správna odpoveď: " + spravneOdpovede.get(9));

        obrazok1.setImageResource(obrazky.get(0)); // vložíme obrázky značiek, ktoré sa nachádzali na splnenom teste
        obrazok2.setImageResource(obrazky.get(1));
        obrazok3.setImageResource(obrazky.get(2));
        obrazok4.setImageResource(obrazky.get(3));
        obrazok5.setImageResource(obrazky.get(4));

        ukonceniePrehladu = findViewById(R.id.ukoncitPrehlad);
        ukonceniePrehladu.setBackgroundColor(Color.rgb(185,85,255));
    }

    public void ukonceniePrehladu(View view) { // pomocou onClick metódy ukonceniePrehladu sa po kliknutí na tlačidlo Ukončiť prehľad zobrazí Alert Dialog s výberom či chce používateľ prejsť do hlavného menu alebo vyplniť ešte jeden test
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(TestyPrehlad.this, R.style.AlertDialogStyle);
        alertDialogBuilder.setTitle("Ukončenie prehľadu!")
                .setMessage("Môžete absolvovať ďaľší test alebo sa vrátiť do hlavného menu.")
                .setNeutralButton("Hlavné menu", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(TestyPrehlad.this, HlavneMenu.class);
                        startActivity(intent);
                        finish(); // pri výbere odpovede Hlavné menu sa vytvorí Intent a presunieme sa do Hlavného menu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                    }
                })
                .setPositiveButton("Nový test", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(TestyPrehlad.this, Testy.class);
                        startActivity(intent);
                        finish(); // pri výbere odpovede Nový test sa vytvorí Intent a presunieme sa do ďaľšieho testu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
        alertDialog.getButton(alertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(187,134,252));
        alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(65,200,0));
    }
}
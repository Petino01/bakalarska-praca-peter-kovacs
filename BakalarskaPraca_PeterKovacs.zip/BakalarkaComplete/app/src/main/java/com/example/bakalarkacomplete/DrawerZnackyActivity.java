package com.example.bakalarkacomplete;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;

import com.google.android.material.navigation.NavigationView;

public class DrawerZnackyActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;

    @Override
    public void setContentView(View view) {
        drawerLayout = (DrawerLayout) getLayoutInflater().inflate(R.layout.activity_drawer_znacky, null);
        FrameLayout container = drawerLayout.findViewById(R.id.activityContainer);
        container.addView(view);
        super.setContentView(drawerLayout); // priradenie layoutu obsahujúceho menu prvky a im prislúchané ikonky

        Toolbar toolbar = drawerLayout.findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        NavigationView navigationView = drawerLayout.findViewById(R.id.znackynav);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
        DrawerLayout.LayoutParams params = (DrawerLayout.LayoutParams) navigationView.getLayoutParams();
        double sirka = getDisplay().getWidth();
        double sirkaUpravena = sirka / 1.25;

        params.width = (int) sirkaUpravena; // nastavenie navigationView aby sa zobrazovalo na 75% šírky displeja

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.menu_drawer_open, R.string.menu_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) { // switch case pre jednotlivé menu prvky
        drawerLayout.closeDrawer(GravityCompat.START);

        switch (item.getItemId()) { // pri každom prvku menu nastavený Intent na prechod do príslušnej aktivity nasledovaný príkazom finish() -> ukončenie aktuálnej aktivity
            case R.id.vystrazne:
                startActivity(new Intent(this, VystrazneZnacky.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.regulacne:
                startActivity(new Intent(this, RegulacneZnacky.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.informacne:
                startActivity(new Intent(this, InformacneZnacky.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.dodatkove:
                startActivity(new Intent(this, DodatkoveTabulky.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.vodorovne:
                startActivity(new Intent(this, VodorovneZnacky.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.svetelne:
                startActivity(new Intent(this, SvetelneSignaly.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.pokyny:
                startActivity(new Intent(this, PokynyPolicajta.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.symboly:
                startActivity(new Intent(this, Symboly.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.vratenieSa:
                startActivity(new Intent(this, HlavneMenu.class));
                finish();
                overridePendingTransition(0,0);
                break;

            case R.id.oAplikacii: // pri možnosti o Aplikácii sa zobrazí Alert Dialog obsahujúci informácie o aplikácii s neutrálnym tlačidlom pre zavretie Alert Dialogu
                AlertDialog.Builder alertDialogBuilder1 = new AlertDialog.Builder(DrawerZnackyActivity.this, R.style.AlertDialogStyle);
                alertDialogBuilder1.setMessage("Bakalárska práca\n© Peter Kovács 2023")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                AlertDialog alertDialog1 = alertDialogBuilder1.create();
                alertDialog1.setCancelable(false);
                alertDialog1.show();
                alertDialog1.getButton(alertDialog1.BUTTON_POSITIVE).setTextColor(Color.rgb(187,134,252));
                break;

            case R.id.odistAplikacia: // pri možnosti Odísť z aplikácie sa zobrazí Alert Dialog so správou či si naozaj používateľ praje opustiť aplikáciu, pozitívne a negatívne tlačidlo s možnosťami nie a áno
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DrawerZnackyActivity.this, R.style.AlertDialogStyle);
                alertDialogBuilder.setTitle("Opustiť aplikáciu")
                        .setMessage("Naozaj si prajete opustiť aplikáciu?")
                        .setNegativeButton("Nie", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel(); // pri odpovedi nie sa Alert Dialog len zatvorí
                            }
                        })
                        .setPositiveButton("Áno", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finish();
                                System.exit(0); // pri odpovedi áno sa ukončí aktuálna aktivita a pomocou System.exit(0) sa aplikácia vypne
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.setCancelable(false);
                alertDialog.show();
                alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(65,200,0));
                alertDialog.getButton(alertDialog.BUTTON_NEGATIVE).setTextColor(Color.rgb(225,15,15));
                break;
        }
        return false;
    }
}
package com.example.bakalarkacomplete;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.bakalarkacomplete.databinding.ActivityZnackyBinding;

public class Znacky extends DrawerZnackyActivity {

    ActivityZnackyBinding activityZnackyBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityZnackyBinding = ActivityZnackyBinding.inflate(getLayoutInflater());
        setContentView(activityZnackyBinding.getRoot());

        getSupportActionBar().setTitle("Dopravné značky");
    }

    // pomocou onClick metód pre každý ImageView sa vytvorí daný Intent s presunom na príslušnú aktivitu, po presune do novej aktivity sa aktuálna aktivita ukončí pomocou príkazu finish()
    public void vystraznePresun(View view) {
        Intent intent = new Intent(Znacky.this, VystrazneZnacky.class);
        startActivity(intent);
        finish();
    }

    public void regulacnePresun(View view) {
        Intent intent = new Intent(Znacky.this, RegulacneZnacky.class);
        startActivity(intent);
        finish();
    }

    public void informacnePresun(View view) {
        Intent intent = new Intent(Znacky.this, InformacneZnacky.class);
        startActivity(intent);
        finish();
    }

    public void dodatkovePresun(View view) {
        Intent intent = new Intent(Znacky.this, DodatkoveTabulky.class);
        startActivity(intent);
        finish();
    }

    public void vodorovnePresun(View view) {
        Intent intent = new Intent(Znacky.this, VodorovneZnacky.class);
        startActivity(intent);
        finish();
    }

    public void svetelnePresun(View view) {
        Intent intent = new Intent(Znacky.this, SvetelneSignaly.class);
        startActivity(intent);
        finish();
    }

    public void pokynyPresun(View view) {
        Intent intent = new Intent(Znacky.this, PokynyPolicajta.class);
        startActivity(intent);
        finish();
    }

    public void symbolyPresun(View view) {
        Intent intent = new Intent(Znacky.this, Symboly.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
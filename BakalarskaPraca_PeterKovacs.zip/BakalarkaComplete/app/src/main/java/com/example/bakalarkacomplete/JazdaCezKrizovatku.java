package com.example.bakalarkacomplete;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityJazdaCezKrizovatkuBinding;

public class JazdaCezKrizovatku extends DrawerTeoriaActivity {

    ActivityJazdaCezKrizovatkuBinding activityJazdaCezKrizovatkuBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityJazdaCezKrizovatkuBinding = ActivityJazdaCezKrizovatkuBinding.inflate(getLayoutInflater());
        setContentView(activityJazdaCezKrizovatkuBinding.getRoot());

        int[] nadpisy = {R.id.prvyNadpis, R.id.druhyNadpis, R.id.tretiNadpis, R.id.stvrtyNadpis}; // pole intov s odkazmi na TextView nadpisy v layoute
        int[] texty = {R.id.prvyText, R.id.druhyText, R.id.tretiText, R.id.stvrtyText, R.id.piatyText, R.id.siestyText, R.id.siedmyText, R.id.osmyText, R.id.deviatyText}; // pole intov s odkazmi na TextView texty v layoute
        int[] popisy = {R.id.prvyPopis, R.id.druhyPopis, R.id.tretiPopis, R.id.stvrtyPopis, R.id.piatyPopis, R.id.siestyPopis, R.id.siedmyPopis, R.id.osmyPopis, R.id.deviatyPopis, R.id.desiatyPopis, // pole intov s odkazmi na TextView popisy v layoute
                        R.id.jedenastyPopis, R.id.dvanastyPopis, R.id.trinastyPopis, R.id.strnastyPopis, R.id.patnastyPopis, R.id.sestnastyPopis, R.id.sedemnastyPopis, R.id.osemnastyPopis, R.id.devatnastyPopis, R.id.dvadsiatyPopis};

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            for(int id: popisy) { // pomocou for cyklov priradíme všetkým popisom, nadpisom a textom príslušnú veľkosť pre danú veľkosť obrazovky
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(16);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(22);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(18);
            }
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(19);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(25);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(21);
            }
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(22);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(28);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(24);
            }
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(25);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(31);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(27);
            }
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(28);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(34);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(30);
            }
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(31);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(37);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(33);
            }
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(34);
            }
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(40);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(36);
            }
        }

        getSupportActionBar().setTitle("Jazda cez križovatku");
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
package com.example.bakalarkacomplete;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityNemotoroveVozidlaBinding;

public class NemotoroveVozidla extends DrawerTeoriaActivity {

    ActivityNemotoroveVozidlaBinding activityNemotoroveVozidlaBinding;

    TextView prvyPopis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityNemotoroveVozidlaBinding = ActivityNemotoroveVozidlaBinding.inflate(getLayoutInflater());
        setContentView(activityNemotoroveVozidlaBinding.getRoot());

        int[] nadpisy = {R.id.prvyNadpis, R.id.druhyNadpis, R.id.tretiNadpis, R.id.stvrtyNadpis}; // pole intov s odkazmi na TextView nadpisy v layoute
        int[] texty = {R.id.prvyText, R.id.druhyText, R.id.tretiText, R.id.stvrtyText, R.id.piatyText}; // pole intov s odkazmi na TextView texty v layoute

        prvyPopis = findViewById(R.id.prvyPopis);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            for(int id: nadpisy) { // pomocou for cyklov priradíme všetkým nadpisom, textom a popisu príslušnú veľkosť pre danú veľkosť obrazovky
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(22);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(18);
            }
            prvyPopis.setTextSize(16);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(25);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(21);
            }
            prvyPopis.setTextSize(19);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(28);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(24);
            }
            prvyPopis.setTextSize(22);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(31);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(27);
            }
            prvyPopis.setTextSize(25);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(34);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(30);
            }
            prvyPopis.setTextSize(28);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(37);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(33);
            }
            prvyPopis.setTextSize(31);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            for(int id: nadpisy) {
                TextView nadpis = (TextView) findViewById(id);
                nadpis.setTextSize(40);
            }
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(36);
            }
            prvyPopis.setTextSize(34);
        }

        getSupportActionBar().setTitle("Nemotorové vozidlá");
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
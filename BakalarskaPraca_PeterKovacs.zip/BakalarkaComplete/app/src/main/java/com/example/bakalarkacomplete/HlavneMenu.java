package com.example.bakalarkacomplete;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityHlavneMenuBinding;

public class HlavneMenu extends DrawerActivity {

    ActivityHlavneMenuBinding activityHlavneMenuBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityHlavneMenuBinding = ActivityHlavneMenuBinding.inflate(getLayoutInflater());
        setContentView(activityHlavneMenuBinding.getRoot());

        int[] texty = {R.id.teoriaText, R.id.znackyText, R.id.animacieText, R.id.testyText, R.id.pribehText, R.id.krizovatkyText, R.id.pexesoText, R.id.opustitText}; // pole intov s odkazmi na TextViews v layoute

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            for(int id: texty) { // pomocou for cyklu nastavíme všetkým textom v TextView-och daný textSize pre danú veľkosť obrazovky
                TextView text = (TextView) findViewById(id);
                text.setTextSize(16);
            }
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(19);
            }
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(22);
            }
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(25);
            }
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(28);
            }
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(31);
            }
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(34);
            }
        }
    }
    // metódy onClick pre jednotlivé ImageViews ... každá metóda obsahuje Intent pomocou ktorého sa dostaneme do príslušnej aktivity a následne sa pomocou príkazu finish() aktuálna aktivita ukončí
    public void presunTeoria(View view) {
        startActivity(new Intent(this, Teoria.class));
        finish();
    }

    public void presunZnacky(View view) {
        startActivity(new Intent(this, Znacky.class));
        finish();
    }

    public void presunAnimacie(View view) {
        startActivity(new Intent(this, Animacie.class));
        finish();
    }

    public void presunTesty(View view) {
        startActivity(new Intent(this, Testy.class));
        finish();
    }

    public void presunPribeh(View view) {
        startActivity(new Intent(this, Pribeh.class));
        finish();
    }

    public void presunKrizovatkyHra(View view) {
        startActivity(new Intent(this, KrizovatkyHra.class));
        finish();
    }

    public void presunPexeso(View view) {
        startActivity(new Intent(this, Pexeso.class));
        finish();
    }

    public void opustitAplikacia(View view) { // pri kliknutí na ImageView s onClick metódou opustitAplikacia sa zobrazí Alert Dialog s otázkou či si používateľ naozaj praje opustiť aplikáciu ... pozitívne a negatívne tlačidlo
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HlavneMenu.this, R.style.AlertDialogStyle);
        alertDialogBuilder.setTitle("Opustiť aplikáciu")
                .setMessage("Naozaj si prajete opustiť aplikáciu?")
                .setNegativeButton("Nie", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel(); // pri odpovedi nie sa Alert Dialog len zavrie
                    }
                })
                .setPositiveButton("Áno", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0); // pri odpovedi áno sa aktuálna aktivita ukončí a pomocou príkazu System.exit(0) sa aplikácia vypne
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
        alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(22,222,0));
        alertDialog.getButton(alertDialog.BUTTON_NEGATIVE).setTextColor(Color.rgb(222,0,0));
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
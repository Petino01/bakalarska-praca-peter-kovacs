package com.example.bakalarkacomplete;

public class OtazkyOdpovedePribeh {
    public static String pribehText[] = {
            "Na konci ulice, kde Maťko chodí do školy, sa nachádza prvá križovatka.\n\nTáto križovatka je zvláštna, pretože tu nie sú žiadne dopravné značky.\n\nVšetky cesty sú rovnocenné.\n\nNáš malý žiačik vie, aké pravidlá tu platia, a preto prejde cez križovatku ako:",
            "Maťko prišiel na ďaľšiu križovatku.\n\nNa tejto križovatke je prednosť v jazde vyznačená dopravnými značkami. Cesta domov vedie vľavo, a preto musí náš malý žiačik odbočiť vľavo.\n\nNachádza sa na vedľajšej ceste a na hlavnej ceste idú v priamom smere dve vozidlá.\n\nZo situácie vyplýva, že Maťko prejde cez križovatku ako:",
            "Maťko prišiel na ďaľšiu križovatku.\n\nNa tejto križovatke je prednosť v jazde vyznačená dopravnými značkami. Cesta domov vedie vľavo, a preto musí náš malý žiačik odbočiť vľavo.\n\nNa hlavnej ceste sa nachádza zelené vozidlo. Na vedľajších cestách sa nachádzajú červené vozidlo a náš cyklista. Obidvaja odbočujú vľavo.\n\nZo situácie vyplýva, že Maťko prejde cez križovatku ako:",
            "Maťko prišiel na ďaľšiu križovatku.\n\nPrednosť v jazde je vyznačená dopravnými značkami. Na hlavnej ceste sa nachádza zelené vozidlo a náš cyklista, ktorý odbočuje vľavo. Na vedľajšej ceste sa nachádza červené vozidlo.\n\nMaťko dobre pozná pravidlá cestnej premávky a tak prejde cez križovatku ako:",
            "Maťko prišiel na jeden z dvoch kruhových objazdov v meste.\n\nPrednosť v jazde je vyznačená dopravnými značkami.\n\nNa hlavnej ceste sa nachádza červené vozidlo a na vedľajšej ceste, ktorá sa pripája do kruhového objazdu, sa nachádza náš malý cyklista.\n\nNič jednoduchšie ho nemohlo stretnúť a tak prejde cez križovatku ako:",
            "Maťko prišiel na ďaľšiu križovatku.\n\nNa tejto križovatke je prednosť v jazde vyznačená dopravnými značkami.\n\nPo hlavnej ceste jazdia električky a na vedľajších cestách sa nachádza žlté vozidlo a náš žiačik.\n\nSituácia je veľmi jednoduchá a tak Maťko prejde cez križovatku ako:",
            "Maťko prišiel na ďaľšiu križovatku.\n\nTáto križovatka je zvláštna, lebo prednosť v jazde je vyznačená dopravnými značkami a zároveň sú tu aj semafory.\n\nV tejto dopravnej sitácii sa nachádza červené vozidlo odbočujúce vľavo, zelené vozidlo, električka a náš žiačik.\n\nPo zvážení danej situácie Maťko prejde cez križovatku ako:"
    };

    public static String odpovede[][] = {
            {"prvý", "druhý", "posledný"}, {"prvý", "druhý", "prvý súčasne so zeleným vozidlom"}, {"prvý", "druhý súčasne s červeným vozidlom", "prvý súčasne s červeným vozidlom"}, {"prvý", "druhý", "posledný"}, {"prvý", "druhý", "prvý súčasne s červeným vozidlom"}, {"prvý", "prvý súčasne so žltým vozidlom", "posledný súčasne so žltým vozidlom"}, {"prvý", "druhý", "tretí"}
    };

    public static String spravneOdpovede[] = {
            "posledný", "druhý", "druhý súčasne s červeným vozidlom", "druhý", "druhý", "posledný súčasne so žltým vozidlom", "tretí"
    };

    public static int videa[] = {
            R.raw.kr1, R.raw.kr2, R.raw.kr3, R.raw.kr4, R.raw.kr5, R.raw.kr6, R.raw.kr7
    };
}


// databáza pre aktivitu Príbeh ... obsahuje texty príbehu, odpovede k daným otázkam vyplývajúcim z textov, správne odpovede a odkazy na videá
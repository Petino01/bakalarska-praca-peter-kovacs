package com.example.bakalarkacomplete;

public class PexesoDatabaza {
    public static int[] znacky = {
              R.drawable.dod01, R.drawable.dod02, R.drawable.dod03, R.drawable.dod04, R.drawable.dod05, R.drawable.dod06, R.drawable.dod07, R.drawable.dod08, R.drawable.dod09,
              R.drawable.inf01, R.drawable.inf02, R.drawable.inf03, R.drawable.inf04, R.drawable.inf05, R.drawable.inf06, R.drawable.inf07, R.drawable.inf08, R.drawable.inf09, R.drawable.inf10, R.drawable.inf11, R.drawable.inf12,
              R.drawable.inf13, R.drawable.inf14, R.drawable.inf15, R.drawable.inf16, R.drawable.inf17, R.drawable.inf18, R.drawable.inf19, R.drawable.inf20, R.drawable.inf21, R.drawable.inf22, R.drawable.pok01, R.drawable.pok02,
              R.drawable.pok03, R.drawable.pok04, R.drawable.pok05, R.drawable.pok06, R.drawable.reg01, R.drawable.reg02, R.drawable.reg03, R.drawable.reg04, R.drawable.reg05, R.drawable.reg06, R.drawable.reg07, R.drawable.reg08,
              R.drawable.reg09, R.drawable.reg10, R.drawable.reg11, R.drawable.reg12, R.drawable.reg13, R.drawable.reg14, R.drawable.reg15, R.drawable.reg16, R.drawable.reg17, R.drawable.reg18, R.drawable.reg19, R.drawable.reg20,
              R.drawable.reg21, R.drawable.reg22, R.drawable.sve01, R.drawable.sve02, R.drawable.sve03, R.drawable.sve04, R.drawable.sve05, R.drawable.sve06, R.drawable.sve07, R.drawable.sve08, R.drawable.sve09, R.drawable.sve10,
              R.drawable.sve11, R.drawable.sve12, R.drawable.sve13, R.drawable.sve14, R.drawable.sym01 ,R.drawable.sym02, R.drawable.sym03 ,R.drawable.sym04, R.drawable.sym05 ,R.drawable.sym06, R.drawable.sym07 ,R.drawable.sym08,
              R.drawable.vod01, R.drawable.vod02, R.drawable.vod03, R.drawable.vod04, R.drawable.vod05, R.drawable.vod06, R.drawable.vod07, R.drawable.vys01, R.drawable.vys02, R.drawable.vys03, R.drawable.vys04, R.drawable.vys05,
              R.drawable.vys06, R.drawable.vys07, R.drawable.vys08, R.drawable.vys09, R.drawable.vys10, R.drawable.vys11, R.drawable.vys12, R.drawable.vys13, R.drawable.vys14, R.drawable.vys15
    };
}

// databáza pre aktivitu Pexeso ... obsahuje odkazy ku všetkým obrázkom značiek

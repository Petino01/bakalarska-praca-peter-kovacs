package com.example.bakalarkacomplete;

public class AnimacieDatabaza {
    public static int[] animacie = {
            R.raw.kr1, R.raw.kr2, R.raw.kr3, R.raw.kr4, R.raw.kr5, R.raw.kr6, R.raw.kr7
    };

    public static String[] popis = {
            "Dopravná situácia sa rieši prednosťou sprava, to znamená, že prednosť v jazde má vždy vozidlo prichádzajúce sprava.\n\nCyklista je povinný dať prednosť v jazde modrému vozidlu a vodič modrého vozidla je povinný dať prednosť v jazde žltému vozidlu.",
            "Vozidlo idúce po vedľajšej ceste musí dať prednosť v jazde vozidlu idúcemu po hlavnej ceste. Prednosť v jazde majú vždy vozidlá na hlavnej ceste.\n\nModré vozidlo aj zelené vozidlo sú na hlavnej ceste a cyklista je na vedľajšej ceste.",
            "Vozidlo idúce po vedľajšej ceste musí dať prednosť v jazde vozidlu idúcemu po hlavnej ceste. Prednosť v jazde majú vždy vozidlá na hlavnej ceste.\n\nCyklista a zelené vozidlo sú na hlavnej ceste a červené vozidlo je na vedľajšej ceste. Cyklista je na hlavnej ceste, ale pri odbočovaní vľavo musí dať prednosť v jazde protiidúcemu zelenému vozidlu na hlavnej ceste.\n\nNakoniec prejde križovatkou červené vozidlo, ktoré je na vedľajšej ceste.",
            "Vozidlo idúce po vedľajšej ceste musí dať prednosť v jazde vozidlu idúcemu po hlavnej ceste. Prednosť v jazde majú vždy vozidlá na hlavnej ceste.\n\nZelené vozidlo je na hlavnej ceste. Cyklista a červené vozidlo sú na vedľajších cestách a obe odbočujú vľavo, pričom si vzájomne nekrižujú cestu, môžu križovatkou prejsť súčasne. Vozidlá odbočujúce vľavo sa vyhýbajú vľavo.",
            "Vozidlo idúce po vedľajšej ceste musí dať prednosť v jazde vozidlu idúcemu po hlavnej ceste. Prednosť v jazde majú vždy vozidlá na hlavnej ceste.\n\nŽlté vozidlo sa nachádza v kruhovom objazde, ktorý v tejto dopravnej situácii predstavuje hlavnú cestu.\n\nCyklista prichádza ku kruhovému objazdu po vedľajšej ceste. Žlté vozidlo má pred cyklistom prednosť v jazde.\n\nCyklista vchádzajúci do kruhového objazdu znamenie o zmene smeru jazdy nedáva. Znamenie o zmene smeru jazdy sa dáva, keď vozidlo z kruhového objazdu vychádza.",
            "Vozidlo idúce po vedľajšej ceste musí dať prednosť v jazde vozidlu idúcemu po hlavnej ceste. Prednosť v jazde majú vždy vozidlá na hlavnej ceste.\n\nObidve električky sú na hlavnej ceste, a preto prechádzajú cez križovatku súčasne ako prvé. Potom prejdú križovatkou vozidlá na vedľajších cestách, to znamená cyklista a žlté vozidlo súčasne.",
            "Vodič vozidla, ktorému svieti signál „Voľno“ - zelené svetlo, má prednosť v jazde. Červené svetlo znamená „Stoj“.\n\nCyklista, protiidúce zelené vozidlo a električka majú voľno, červené vozidlo má červené svetlo „Stoj“.\n\nElektrička odbočujúca vpravo má prednosť v jazde pred zeleným vozidlom a cyklistom, ktorý odbočuje vľavo.\n\nCyklista odbočujúci vľavo musí dať prednosť v jazde ako električke, tak aj zelenému vozidlu. Po zmene svetelného signálu prejde križovatkou červené vozidlo."
    };
}

// databáza pre aktivitu Animácie obsahujúca odkazy na videá a príslušné popisy k daným videám
package com.example.bakalarkacomplete;

import androidx.appcompat.app.AlertDialog;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityPexesoBinding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Pexeso extends DrawerActivity {

    ActivityPexesoBinding activityPexesoBinding;

    ImageView z11, z12, z13, z14, z21, z22, z23, z24, z31, z32, z33, z34, z41, z42, z43, z44;

    Integer[] pexesoPole = {11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 26, 27, 28}; // pole prvkov hracej plochy

    int znacka01, znacka02, znacka03, znacka04, znacka05, znacka06, znacka07, znacka08, znacka11, znacka12, znacka13, znacka14, znacka15, znacka16, znacka17, znacka18;

    int znackaS01, znackaS02, znackaS03, znackaS04, znackaS05, znackaS06, znackaS07, znackaS08, znackaS11, znackaS12, znackaS13, znackaS14, znackaS15, znackaS16, znackaS17, znackaS18;

    int prvaZnacka, druhaZnacka;
    int prvyVyber, druhyVyber;
    int cisloZnacky = 1;

    TextView casomiera;

    Timer timer;

    TimerTask timerTask;

    double cas = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityPexesoBinding = ActivityPexesoBinding.inflate(getLayoutInflater());
        setContentView(activityPexesoBinding.getRoot());

        getSupportActionBar().setTitle("Pexeso");

        znackaS01 = 0;
        znackaS02 = 0;
        znackaS03 = 0;
        znackaS04 = 0;
        znackaS05 = 0;
        znackaS06 = 0;
        znackaS07 = 0;
        znackaS08 = 0;
        znackaS11 = 0;
        znackaS12 = 0;
        znackaS13 = 0;
        znackaS14 = 0;
        znackaS15 = 0;
        znackaS16 = 0;
        znackaS17 = 0;
        znackaS18 = 0; // inicializácia hodnôt pre dané políčka na hodnotu 0

        z11 = findViewById(R.id.z11);
        z12 = findViewById(R.id.z12);
        z13 = findViewById(R.id.z13);
        z14 = findViewById(R.id.z14);

        z21 = findViewById(R.id.z21);
        z22 = findViewById(R.id.z22);
        z23 = findViewById(R.id.z23);
        z24 = findViewById(R.id.z24);

        z31 = findViewById(R.id.z31);
        z32 = findViewById(R.id.z32);
        z33 = findViewById(R.id.z33);
        z34 = findViewById(R.id.z34);

        z41 = findViewById(R.id.z41);
        z42 = findViewById(R.id.z42);
        z43 = findViewById(R.id.z43);
        z44 = findViewById(R.id.z44);

        z11.setTag("0");
        z12.setTag("1");
        z13.setTag("2");
        z14.setTag("3");

        z21.setTag("4");
        z22.setTag("5");
        z23.setTag("6");
        z24.setTag("7");

        z31.setTag("8");
        z32.setTag("9");
        z33.setTag("10");
        z34.setTag("11");

        z41.setTag("12");
        z42.setTag("13");
        z43.setTag("14");
        z44.setTag("15"); // nastavenie tagov pre dané políčka

        nacitajZnacky(); // zavolá sa metóda pre načítanie značiek

        Collections.shuffle(Arrays.asList(pexesoPole)); // zamiešanie poradia ako budú zobrazené značky na hracej ploche

        z11.setOnClickListener(new View.OnClickListener() { // nastavenie onClickListenerov pre dané políčka na hracej ploche
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z11, znacka); // zavolanie metódy vykonaj s hodnotou ImageView a int
            }
        });

        z12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z12, znacka);
            }
        });

        z13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z13, znacka);
            }
        });

        z14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z14, znacka);
            }
        });

        z21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z21, znacka);
            }
        });

        z22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z22, znacka);
            }
        });

        z23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z23, znacka);
            }
        });

        z24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z24, znacka);
            }
        });

        z31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z31, znacka);
            }
        });

        z32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z32, znacka);
            }
        });

        z33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z33, znacka);
            }
        });

        z34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z34, znacka);
            }
        });

        z41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z41, znacka);
            }
        });

        z42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z42, znacka);
            }
        });

        z43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z43, znacka);
            }
        });

        z44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int znacka = Integer.parseInt((String) v.getTag());
                vykonaj(z44, znacka);
            }
        });

        casomiera = findViewById(R.id.casomiera);

        timer = new Timer(); // inicializácia Timera

        timerTask = new TimerTask() {
            @Override
            public void run() {
                cas++;
                casomiera.setText(upravenyCas());
            }
        };
        timer.scheduleAtFixedRate(timerTask, 0, 1000); // pribúdanie času po jednej sekunde
    }

    public String upravenyCas() { // metóda na úpravu zobrazenia času
        int zaokruhlene = (int) Math.round(cas); // zaokrúhlenie času

        int sekundy = ((zaokruhlene % 86400) % 3600) % 60; // výpočet sekúnd
        int minuty = ((zaokruhlene % 86400) % 3600) / 60; // výpočet minút

        return casFormat(sekundy, minuty); // vracia hodnoty sekúnd a minút do metódy String
    }

    public String casFormat(int sekundy, int minuty) { // metóda, ktorá vracia hodnoty už upravené ako budú zobrazené na obrazovke
        return String.format("%02d", minuty) + " : " + String.format("%02d", sekundy);
    }

    private void nacitajZnacky() { // metóda pre načítanie značiek
        Random random = new Random();
        ArrayList<Integer> arrayList = new ArrayList<Integer>();

        while(arrayList.size() < 8) { // vytvorí sa ArrayList s 8 náhodnými hodnotami
            int cislo = random.nextInt(103);

            if(!arrayList.contains(cislo)) {
                arrayList.add(cislo);
            }
        }

        znacka01 = PexesoDatabaza.znacky[arrayList.get(0)]; // tieto náhodné hodnoty sa priradia k jednotlivým hracím políčkam z databázy značiek
        znacka02 = PexesoDatabaza.znacky[arrayList.get(1)];
        znacka03 = PexesoDatabaza.znacky[arrayList.get(2)];
        znacka04 = PexesoDatabaza.znacky[arrayList.get(3)];
        znacka05 = PexesoDatabaza.znacky[arrayList.get(4)];
        znacka06 = PexesoDatabaza.znacky[arrayList.get(5)];
        znacka07 = PexesoDatabaza.znacky[arrayList.get(6)];
        znacka08 = PexesoDatabaza.znacky[arrayList.get(7)];

        znacka11 = PexesoDatabaza.znacky[arrayList.get(0)];
        znacka12 = PexesoDatabaza.znacky[arrayList.get(1)];
        znacka13 = PexesoDatabaza.znacky[arrayList.get(2)];
        znacka14 = PexesoDatabaza.znacky[arrayList.get(3)];
        znacka15 = PexesoDatabaza.znacky[arrayList.get(4)];
        znacka16 = PexesoDatabaza.znacky[arrayList.get(5)];
        znacka17 = PexesoDatabaza.znacky[arrayList.get(6)];
        znacka18 = PexesoDatabaza.znacky[arrayList.get(7)];
    }

    private void vykonaj(ImageView imageView, int znacka) { // metóda pre priradenie obrázkov k jednotlivým hracím políčkam
        if(pexesoPole[znacka] == 11) {
            imageView.setImageResource(znacka01);
        } else if(pexesoPole[znacka] == 12) {
            imageView.setImageResource(znacka02);
        } else if(pexesoPole[znacka] == 13) {
            imageView.setImageResource(znacka03);
        } else if(pexesoPole[znacka] == 14) {
            imageView.setImageResource(znacka04);
        } else if(pexesoPole[znacka] == 15) {
            imageView.setImageResource(znacka05);
        } else if(pexesoPole[znacka] == 16) {
            imageView.setImageResource(znacka06);
        } else if(pexesoPole[znacka] == 17) {
            imageView.setImageResource(znacka07);
        } else if(pexesoPole[znacka] == 18) {
            imageView.setImageResource(znacka08);
        } else if(pexesoPole[znacka] == 21) {
            imageView.setImageResource(znacka11);
        } else if(pexesoPole[znacka] == 22) {
            imageView.setImageResource(znacka12);
        } else if(pexesoPole[znacka] == 23) {
            imageView.setImageResource(znacka13);
        } else if(pexesoPole[znacka] == 24) {
            imageView.setImageResource(znacka14);
        } else if(pexesoPole[znacka] == 25) {
            imageView.setImageResource(znacka15);
        } else if(pexesoPole[znacka] == 26) {
            imageView.setImageResource(znacka16);
        } else if(pexesoPole[znacka] == 27) {
            imageView.setImageResource(znacka17);
        } else if(pexesoPole[znacka] == 28) {
            imageView.setImageResource(znacka18);
        }

        if(cisloZnacky == 1) { // ak sa jedná o prvý výber vykoná sa nasledovné
            prvaZnacka = pexesoPole[znacka];
            if(prvaZnacka > 20) {
                prvaZnacka = prvaZnacka - 10; // uloží sa hodnota na neskoršie porovnávanie
            }
            cisloZnacky = 2; // prejde sa na druhý výber
            prvyVyber = znacka; // do prvého výberu sa uloží vybraná značka

            imageView.setEnabled(false); // manipulovanie s vybranou značkou sa dočasne zablokuje
        } else if(cisloZnacky == 2) { // ak sa jedná o druhý výber vykoná sa nasledovné
            druhaZnacka = pexesoPole[znacka];
            if(druhaZnacka > 20) {
                druhaZnacka = druhaZnacka - 10; // uloží sa hodnota na neskoršie porovnávanie
            }
            cisloZnacky = 1; // prejde sa opäť na prvý výber
            druhyVyber = znacka; // do druhého výberu sa uloží vybraná značka

            z11.setEnabled(false);
            z12.setEnabled(false);
            z13.setEnabled(false);
            z14.setEnabled(false);
            z21.setEnabled(false);
            z22.setEnabled(false);
            z23.setEnabled(false);
            z24.setEnabled(false);
            z31.setEnabled(false);
            z32.setEnabled(false);
            z33.setEnabled(false);
            z34.setEnabled(false);
            z41.setEnabled(false);
            z42.setEnabled(false);
            z43.setEnabled(false);
            z44.setEnabled(false); // všetky herné políčka sa dočasne zablokujú

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    zistiCiSuRovnake();
                }
            }, 1000); // na konci tejto metódy sa vykoná zavolanie metódy zistiCiSuRovnake a následne sa aplikuje delay 1 sekunda
        }
    }

    private void zistiCiSuRovnake() { // metóda pre zistenie či dané dve značky sú rovnaké
        if(prvaZnacka == druhaZnacka) { // ak sa vyššie spomínaná hodnota prvej a druhej značky rovná, vykoná sa nasledovné
            if(prvyVyber == 0) { // pomocou tagov porovnávame ktoré políčko obsahuje prvý výber
                znackaS01 = 1; // hodnota sa zmení na 1
            } else if(prvyVyber == 1) {
                znackaS02 = 1;
            } else if(prvyVyber == 2) {
                znackaS03 = 1;
            } else if(prvyVyber == 3) {
                znackaS04 = 1;
            } else if(prvyVyber == 4) {
                znackaS05 = 1;
            } else if(prvyVyber == 5) {
                znackaS06 = 1;
            } else if(prvyVyber == 6) {
                znackaS07 = 1;
            } else if(prvyVyber == 7) {
                znackaS08 = 1;
            } else if(prvyVyber == 8) {
                znackaS11 = 1;
            } else if(prvyVyber == 9) {
                znackaS12 = 1;
            } else if(prvyVyber == 10) {
                znackaS13 = 1;
            } else if(prvyVyber == 11) {
                znackaS14 = 1;
            } else if(prvyVyber == 12) {
                znackaS15 = 1;
            } else if(prvyVyber == 13) {
                znackaS16 = 1;
            } else if(prvyVyber == 14) {
                znackaS17 = 1;
            } else if(prvyVyber == 15) {
                znackaS18 = 1;
            }

            if(druhyVyber == 0) { // podobným spôsobom skontrolujeme aj druhý výber
                znackaS01 = 1;
            } else if(druhyVyber == 1) {
                znackaS02 = 1;
            } else if(druhyVyber == 2) {
                znackaS03 = 1;
            } else if(druhyVyber == 3) {
                znackaS04 = 1;
            } else if(druhyVyber == 4) {
                znackaS05 = 1;
            } else if(druhyVyber == 5) {
                znackaS06 = 1;
            } else if(druhyVyber == 6) {
                znackaS07 = 1;
            } else if(druhyVyber == 7) {
                znackaS08 = 1;
            } else if(druhyVyber == 8) {
                znackaS11 = 1;
            } else if(druhyVyber == 9) {
                znackaS12 = 1;
            } else if(druhyVyber == 10) {
                znackaS13 = 1;
            } else if(druhyVyber == 11) {
                znackaS14 = 1;
            } else if(druhyVyber == 12) {
                znackaS15 = 1;
            } else if(druhyVyber == 13) {
                znackaS16 = 1;
            } else if(druhyVyber == 14) {
                znackaS17 = 1;
            } else if(druhyVyber == 15) {
                znackaS18 = 1;
            }

            // ak dané políčka nemajú hodnotu 1 ale 0, čo znamená, že dané políčka neobsahujú značky, ktoré si už našli pár, opäť sa zmenia na aktívne
            if(znackaS01 == 0) {
                z11.setEnabled(true);
            }
            if(znackaS02 == 0) {
                z12.setEnabled(true);
            }
            if(znackaS03 == 0) {
                z13.setEnabled(true);
            }
            if(znackaS04 == 0) {
                z14.setEnabled(true);
            }
            if(znackaS05 == 0) {
                z21.setEnabled(true);
            }
            if(znackaS06 == 0) {
                z22.setEnabled(true);
            }
            if(znackaS07 == 0) {
                z23.setEnabled(true);
            }
            if(znackaS08 == 0) {
                z24.setEnabled(true);
            }
            if(znackaS11 == 0) {
                z31.setEnabled(true);
            }
            if(znackaS12 == 0) {
                z32.setEnabled(true);
            }
            if(znackaS13 == 0) {
                z33.setEnabled(true);
            }
            if(znackaS14 == 0) {
                z34.setEnabled(true);
            }
            if(znackaS15 == 0) {
                z41.setEnabled(true);
            }
            if(znackaS16 == 0) {
                z42.setEnabled(true);
            }
            if(znackaS17 == 0) {
                z43.setEnabled(true);
            }
            if(znackaS18 == 0) {
                z44.setEnabled(true);
            }

        } else { // ak prvý a druhý výber nie je tá istá značka
            if(znackaS01 == 0) { // kontrolujú sa políčka ktoré majú hodnotu 0, čo znamená že tieto políčka ešte nenašli svoj pár
                z11.setImageResource(R.drawable.pexeso_zadna); // zmení sa obrázok naspäť na zadnú časť kartičky
                z11.setEnabled(true); // opäť sa aktivuje klikanie
            }  if (znackaS02 == 0) {
                z12.setImageResource(R.drawable.pexeso_zadna);
                z12.setEnabled(true);
            }  if (znackaS03 == 0) {
                z13.setImageResource(R.drawable.pexeso_zadna);
                z13.setEnabled(true);
            }  if (znackaS04 == 0) {
                z14.setImageResource(R.drawable.pexeso_zadna);
                z14.setEnabled(true);
            }  if (znackaS05 == 0) {
                z21.setImageResource(R.drawable.pexeso_zadna);
                z21.setEnabled(true);
            }  if (znackaS06 == 0) {
                z22.setImageResource(R.drawable.pexeso_zadna);
                z22.setEnabled(true);
            }  if (znackaS07 == 0) {
                z23.setImageResource(R.drawable.pexeso_zadna);
                z23.setEnabled(true);
            }  if (znackaS08 == 0) {
                z24.setImageResource(R.drawable.pexeso_zadna);
                z24.setEnabled(true);
            }  if (znackaS11 == 0) {
                z31.setImageResource(R.drawable.pexeso_zadna);
                z31.setEnabled(true);
            }  if (znackaS12 == 0) {
                z32.setImageResource(R.drawable.pexeso_zadna);
                z32.setEnabled(true);
            }  if (znackaS13 == 0) {
                z33.setImageResource(R.drawable.pexeso_zadna);
                z33.setEnabled(true);
            }  if (znackaS14 == 0) {
                z34.setImageResource(R.drawable.pexeso_zadna);
                z34.setEnabled(true);
            }  if (znackaS15 == 0) {
                z41.setImageResource(R.drawable.pexeso_zadna);
                z41.setEnabled(true);
            }  if (znackaS16 == 0) {
                z42.setImageResource(R.drawable.pexeso_zadna);
                z42.setEnabled(true);
            }  if (znackaS17 == 0) {
                z43.setImageResource(R.drawable.pexeso_zadna);
                z43.setEnabled(true);
            }  if (znackaS18 == 0) {
                z44.setImageResource(R.drawable.pexeso_zadna);
                z44.setEnabled(true);
            }
        }

        zistiKoniec(); // zavolá sa metóda, či nenastal koniec hry
    }

    private void zistiKoniec() { // metóda na zistenie konca hry
        if(znackaS01 == 1 && znackaS02 == 1 && znackaS03 == 1 && znackaS04 == 1 && znackaS05 == 1 && znackaS06 == 1 && znackaS07 == 1 && znackaS08 == 1 &&
                znackaS11 == 1 && znackaS12 == 1 && znackaS13 == 1 && znackaS14 == 1 && znackaS15 == 1 && znackaS16 == 1 && znackaS17 == 1 && znackaS18 == 1) { // ak všetky hracie políčka majú hodnotu 1, čo znamená že každé políčko si našlo svoj pár vykoná sa nasledovné
            timerTask.cancel(); // vypne sa časomiera
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Pexeso.this, R.style.AlertDialogStyle); // zobrazí sa Alert Dialog s dvomi možnosťami
            alertDialogBuilder.setTitle("Koniec hry!")
                    .setMessage("Tvoj čas: " + casomiera.getText().toString()).setCancelable(false) // zobrazí sa informačný text s finálnym časom, ktorý používateľ potreboval na úspešné ukončenie hry
                    .setPositiveButton("Nová hra.", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(getApplicationContext(), Pexeso.class);
                            startActivity(intent);
                            finish(); // pri zvolení možnosti Nová hra sa vytvorí Intent pomocou ktorého sa spustí nová hra pexesa a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                        }
                    })
                    .setNegativeButton("Vráť sa.", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(getApplicationContext(), HlavneMenu.class);
                            startActivity(intent);
                            finish(); // pri zvolení možnosti Vráť sa sa vytvorí Intent pomocou ktorého sa používateľ vráti do Hlavného menu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.setCancelable(false);
            alertDialog.show();
            alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(65,200,0));
            alertDialog.getButton(alertDialog.BUTTON_NEGATIVE).setTextColor(Color.rgb(225,15,15));
        }
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
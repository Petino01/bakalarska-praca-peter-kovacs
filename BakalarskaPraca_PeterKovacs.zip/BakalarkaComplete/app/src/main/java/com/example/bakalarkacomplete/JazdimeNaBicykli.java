package com.example.bakalarkacomplete;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityJazdimeNaBicykliBinding;

public class JazdimeNaBicykli extends DrawerTeoriaActivity {

    ActivityJazdimeNaBicykliBinding activityJazdimeNaBicykliBinding;

    TextView prvyNadpis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityJazdimeNaBicykliBinding = ActivityJazdimeNaBicykliBinding.inflate(getLayoutInflater());
        setContentView(activityJazdimeNaBicykliBinding.getRoot());

        int[] texty = {R.id.prvyText, R.id.druhyText, R.id.tretiText}; // pole intov s odkazmi na TextView texty v layoute
        int[] popisy = {R.id.prvyPopis, R.id.druhyPopis, R.id.tretiPopis, R.id.stvrtyPopis, R.id.piatyPopis, R.id.siestyPopis}; // pole intov s odkazmi na TextView popisy v layoute

        prvyNadpis = findViewById(R.id.prvyNadpis);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            for(int id: texty) { // pomocou for cyklov priradíme všetkým popisom a textom príslušnú veľkosť pre danú veľkosť obrazovky
                TextView text = (TextView) findViewById(id);
                text.setTextSize(18);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(16);
            }
            prvyNadpis.setTextSize(22);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(21);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(19);
            }
            prvyNadpis.setTextSize(25);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(24);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(22);
            }
            prvyNadpis.setTextSize(28);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(27);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(25);
            }
            prvyNadpis.setTextSize(31);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(30);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(28);
            }
            prvyNadpis.setTextSize(34);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(33);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(31);
            }
            prvyNadpis.setTextSize(37);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(36);
            }
            for(int id: popisy) {
                TextView popis = (TextView) findViewById(id);
                popis.setTextSize(34);
            }
            prvyNadpis.setTextSize(40);
        }

        getSupportActionBar().setTitle("Jazdíme na bicykli");
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
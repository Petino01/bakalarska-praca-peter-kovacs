package com.example.bakalarkacomplete;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityTeoriaBinding;

public class Teoria extends DrawerTeoriaActivity {

    ActivityTeoriaBinding activityTeoriaBinding;

    TextView prvyNadpis, prvyText, druhyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityTeoriaBinding = ActivityTeoriaBinding.inflate(getLayoutInflater());
        setContentView(activityTeoriaBinding.getRoot());

        prvyNadpis = findViewById(R.id.prvyNadpis);
        prvyText = findViewById(R.id.prvyText);
        druhyText = findViewById(R.id.druhyText);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            prvyNadpis.setTextSize(22);
            prvyText.setTextSize(18);
            druhyText.setTextSize(18);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            prvyNadpis.setTextSize(25);
            prvyText.setTextSize(21);
            druhyText.setTextSize(21);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            prvyNadpis.setTextSize(28);
            prvyText.setTextSize(24);
            druhyText.setTextSize(24);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            prvyNadpis.setTextSize(31);
            prvyText.setTextSize(27);
            druhyText.setTextSize(27);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            prvyNadpis.setTextSize(34);
            prvyText.setTextSize(30);
            druhyText.setTextSize(30);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            prvyNadpis.setTextSize(37);
            prvyText.setTextSize(33);
            druhyText.setTextSize(33);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            prvyNadpis.setTextSize(40);
            prvyText.setTextSize(36);
            druhyText.setTextSize(36);
        }

        getSupportActionBar().setTitle("Úvod");
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
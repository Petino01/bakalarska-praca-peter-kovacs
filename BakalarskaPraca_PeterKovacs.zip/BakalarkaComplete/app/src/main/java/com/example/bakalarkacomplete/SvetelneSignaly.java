package com.example.bakalarkacomplete;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivitySvetelneSignalyBinding;

public class SvetelneSignaly extends DrawerZnackyActivity {

    ActivitySvetelneSignalyBinding activitySvetelneSignalyBinding;

    TextView nazov, popis;
    ImageView znacka;
    ImageView dolava, doprava;
    int cisloZnacky;
    int pocetZnaciek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activitySvetelneSignalyBinding = ActivitySvetelneSignalyBinding.inflate(getLayoutInflater());
        setContentView(activitySvetelneSignalyBinding.getRoot());

        nazov = (TextView) findViewById(R.id.nazovZnacky);
        popis = (TextView) findViewById(R.id.popis);

        popis.setMovementMethod(new ScrollingMovementMethod()); // zabezpečenie scrollovania textu v TextView

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            popis.setTextSize(18);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            popis.setTextSize(21);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            popis.setTextSize(24);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            popis.setTextSize(27);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            popis.setTextSize(30);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            popis.setTextSize(33);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            popis.setTextSize(36);
        }

        znacka = (ImageView) findViewById(R.id.znacka);

        dolava = (ImageView) findViewById(R.id.dolava);
        doprava = (ImageView) findViewById(R.id.doprava);

        cisloZnacky = 0;

        pocetZnaciek = ZnackyDatabaza.sveNazov.length;

        getSupportActionBar().setTitle("Svetelné signály");
    }

    public void dolava(View view) { // jednoduché zabezpečenie fungovania šípky doľava
        if(cisloZnacky > 0) { // ak je značka v poradí minimálne druhá, odpočíta sa 1 a zobrazí sa značka o jednu pozíciu dozadu v databáze
            cisloZnacky = cisloZnacky - 1;
        } else {
            cisloZnacky = pocetZnaciek - 1; // ak náhodou značka je prvá v poradí, preskočí sa na poslednú
        }
        zmenaZnacky(cisloZnacky); // zavolanie metódy pre zmenu značky
    }

    public void doprava(View view) { // podobný spôsob ako pri posune doľava
        if(cisloZnacky < pocetZnaciek - 1) {
            cisloZnacky = cisloZnacky + 1;
        } else {
            cisloZnacky = 0;
        }
        zmenaZnacky(cisloZnacky);
    }

    public void zmenaZnacky(int cislo) {
        nazov.setText(ZnackyDatabaza.sveNazov[cislo]); // prepísanie názvu značky
        popis.setText(ZnackyDatabaza.svePopis[cislo]); // prepísanie popisu značky
        znacka.setImageResource(ZnackyDatabaza.sveObrazok[cislo]); // nastavenie obrázku značky
        popis.scrollTo(0,0); // tento riadok kódu zabezpečí, aby text v TextView bol vyscrollovaný úplne navrch
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
package com.example.bakalarkacomplete;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityKrizovatkyHraBinding;

import java.util.Arrays;
import java.util.Collections;

public class KrizovatkyHra extends DrawerActivity implements View.OnClickListener {

    ActivityKrizovatkyHraBinding activityKrizovatkyHraBinding;

    TextView textOtazky;
    ImageView obrazokKrizovatky, nespravneObrazok;
    ImageView prveVozidlo, druheVozidlo, tretieVozidlo;
    Button dalejButton;

    int pocetSpravnychKliknuti;
    int pocetKrizovatiek;

    Integer[] poradie = {0, 1, 2, 3, 4, 5, 6}; // pole čísel pre poradie križovatiek
    Integer[] poradieOdpovedi = {0, 1, 2}; // pole čísel pre poradie odpovedí k daným križovatkám

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityKrizovatkyHraBinding = ActivityKrizovatkyHraBinding.inflate(getLayoutInflater());
        setContentView(activityKrizovatkyHraBinding.getRoot());

        textOtazky = findViewById(R.id.textOtazky);
        obrazokKrizovatky = findViewById(R.id.obrazokKrizovatky);
        nespravneObrazok = findViewById(R.id.nespravneObrazok);
        prveVozidlo = findViewById(R.id.prveVozidlo);
        druheVozidlo = findViewById(R.id.druheVozidlo);
        tretieVozidlo = findViewById(R.id.tretieVozidlo);
        dalejButton = findViewById(R.id.dalejButton);

        prveVozidlo.setOnClickListener(this);
        druheVozidlo.setOnClickListener(this);
        tretieVozidlo.setOnClickListener(this);

        dalejButton.setBackgroundColor(Color.rgb(185,85,255));

        nespravneObrazok.setVisibility(View.INVISIBLE);
        dalejButton.setVisibility(View.INVISIBLE);

        pocetSpravnychKliknuti = 0; // nastavíme na 0 pri každom vytvorení aktivity
        pocetKrizovatiek = 0; // nastavíme na 0 pri každom vytvorení aktivity

        Collections.shuffle(Arrays.asList(poradie)); // pri každom vytvorení aktivity sa poradie križovatiek zamieša, čo znamená že by sa nemalo stať, aby križovatky išli v tom istom poradí dvakrát alebo viackrát po sebe

        nacitajKrizovatku(); // zavolanie metódy pre načítanie prvej križovatky

        getSupportActionBar().setTitle("Križovatky (Hra)");
    }

    void nacitajKrizovatku() {
        Collections.shuffle(Arrays.asList(poradieOdpovedi)); // pri každej novej načítanej križovatke sa poradie odpovedí zamieša, čo znamená že by sa nemalo stať, aby odpovede pri danej križovatke boli v tom istom poradí dvakrát alebo viackrát po sebe

        if(pocetKrizovatiek < 7) { // pokým počet križovatiek nepresiahne počet 7, tak sa načíta ďaľšia križovatka
            prveVozidlo.setVisibility(View.VISIBLE);
            druheVozidlo.setVisibility(View.VISIBLE);
            tretieVozidlo.setVisibility(View.VISIBLE);
            dalejButton.setVisibility(View.INVISIBLE); // nastavenie tlačidla ďalej na neviditeľný, zobrazí sa až pri úspešnom splnení celej úlohy

            textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][0]); // načíta sa prvá otázka na danom indexe
            obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][0]); // načíta sa prvý obrázok na danom indexe
            prveVozidlo.setImageResource(KrizovatkyDatabaza.odpovede[poradie[pocetKrizovatiek]][poradieOdpovedi[0]]); // načíta sa prvá odpoveď na danom indexe
            druheVozidlo.setImageResource(KrizovatkyDatabaza.odpovede[poradie[pocetKrizovatiek]][poradieOdpovedi[1]]); // načíta sa druhá odpoveď na danom indexe
            tretieVozidlo.setImageResource(KrizovatkyDatabaza.odpovede[poradie[pocetKrizovatiek]][poradieOdpovedi[2]]); // načíta sa tretia odpoveď na danom indexe

            prveVozidlo.setTag(KrizovatkyDatabaza.odpovede[poradie[pocetKrizovatiek]][poradieOdpovedi[0]]);
            druheVozidlo.setTag(KrizovatkyDatabaza.odpovede[poradie[pocetKrizovatiek]][poradieOdpovedi[1]]);
            tretieVozidlo.setTag(KrizovatkyDatabaza.odpovede[poradie[pocetKrizovatiek]][poradieOdpovedi[2]]); // priradia sa tagy pre príslušné odpovede
        } else { // ak je počet križovatiek 7, vykoná sa nasledovné
            textOtazky.setVisibility(View.INVISIBLE);
            obrazokKrizovatky.setVisibility(View.INVISIBLE);
            prveVozidlo.setVisibility(View.INVISIBLE);
            druheVozidlo.setVisibility(View.INVISIBLE);
            tretieVozidlo.setVisibility(View.INVISIBLE);
            dalejButton.setVisibility(View.INVISIBLE); // všetky prvky v layoute sa nastavia na neviditeľné

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(KrizovatkyHra.this, R.style.AlertDialogStyle); // zobrazí sa Alert Dialog s informáciou, že používateľ úspešne splnil všetky úlohy v hre
                    alertDialogBuilder.setTitle("Splnili ste všetky križovatky!")
                    .setMessage("Môžete sa vrátiť do hlavného menu.")
                    .setNeutralButton("Hlavné menu", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(KrizovatkyHra.this, HlavneMenu.class);
                            startActivity(intent);
                            finish(); // po stlačení možnosti Hlavné menu sa jednoducho vrátime do Hlavného menu a pomocou príkazu finish() sa aktuálna aktivita ukončí
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.setCancelable(false);
            alertDialog.show();
            alertDialog.getButton(alertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(187,134,252));
        }
    }

    @Override
    public void onClick(View view) {
        ImageView kliknutie = (ImageView) view; // nastavenie onClick na ImageView

        if(kliknutie.getId() == R.id.prveVozidlo) { // ak sa klikne na prvý obrázok vykoná sa nasledovné
            if(prveVozidlo.getTag().equals(KrizovatkyDatabaza.prve[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 0) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď prvá vykoná sa nasledovné
                textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][1]); // zmení sa otázka na druhú na danom indexe
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][1]); // zmení sa obrázok na druhý na danom indexe
                prveVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(prveVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }

            if(prveVozidlo.getTag().equals(KrizovatkyDatabaza.druhe[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 1) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď druhá vykoná sa nasledovné
                textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][2]); // zmení sa otázka na tretiu na danom indexe
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][2]); // zmení sa obrázok na tretí na danom indexe
                prveVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(prveVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }

            if(prveVozidlo.getTag().equals(KrizovatkyDatabaza.tretie[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 2) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď tretia vykoná sa nasledovné
                textOtazky.setText("Hurá, splnili ste križovatku!"); // zmení sa otázka na text s úspešnou správou o dokončení danej úlohy
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][3]); // zmení sa obrázok na štvrtý na danom indexe
                prveVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(prveVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }
        }

        if(kliknutie.getId() == R.id.druheVozidlo) { // ak sa klikne na druhý obrázok vykoná sa nasledovné
            if(druheVozidlo.getTag().equals(KrizovatkyDatabaza.prve[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 0) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď prvá vykoná sa nasledovné
                textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][1]); // zmení sa otázka na druhú na danom indexe
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][1]); // zmení sa obrázok na druhý na danom indexe
                druheVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(druheVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }

            if(druheVozidlo.getTag().equals(KrizovatkyDatabaza.druhe[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 1) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď druhá vykoná sa nasledovné
                textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][2]); // zmení sa otázka na tretiu na danom indexe
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][2]); // zmení sa obrázok na tretí na danom indexe
                druheVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(druheVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }

            if(druheVozidlo.getTag().equals(KrizovatkyDatabaza.tretie[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 2) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď tretia vykoná sa nasledovné
                textOtazky.setText("Hurá, splnili ste križovatku!"); // zmení sa otázka na text s úspešnou správou o dokončení danej úlohy
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][3]); // zmení sa obrázok na štvrtý na danom indexe
                druheVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(druheVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }
        }

        if(kliknutie.getId() == R.id.tretieVozidlo) {// ak sa klikne na tretí obrázok vykoná sa nasledovné
            if(tretieVozidlo.getTag().equals(KrizovatkyDatabaza.prve[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 0) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď prvá vykoná sa nasledovné
                textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][1]); // zmení sa otázka na druhú na danom indexe
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][1]); // zmení sa obrázok na druhý na danom indexe
                tretieVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(tretieVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }

            if(tretieVozidlo.getTag().equals(KrizovatkyDatabaza.druhe[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 1) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď druhá vykoná sa nasledovné
                textOtazky.setText(KrizovatkyDatabaza.otazky[poradie[pocetKrizovatiek]][2]); // zmení sa otázka na tretiu na danom indexe
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][2]); // zmení sa obrázok na tretí na danom indexe
                tretieVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(tretieVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }

            if(tretieVozidlo.getTag().equals(KrizovatkyDatabaza.tretie[poradie[pocetKrizovatiek]]) && pocetSpravnychKliknuti == 2) { // ak sa vybraný obrázok rovná správnej odpovedi a je to odpoveď tretia vykoná sa nasledovné
                textOtazky.setText("Hurá, splnili ste križovatku!"); // zmení sa otázka na text s úspešnou správou o dokončení danej úlohy
                obrazokKrizovatky.setImageResource(KrizovatkyDatabaza.castiKrizovatky[poradie[pocetKrizovatiek]][3]); // zmení sa obrázok na štvrtý na danom indexe
                tretieVozidlo.setVisibility(View.INVISIBLE); // daná možnosť sa zmení na neviditeľnú
                nespravneObrazok.setVisibility(View.INVISIBLE);
                pocetSpravnychKliknuti++; // zvýši sa počet správnych kliknutí
            } else {
                if(tretieVozidlo.getVisibility() == View.VISIBLE) {
                    prveVozidlo.setEnabled(false);
                    druheVozidlo.setEnabled(false);
                    tretieVozidlo.setEnabled(false);
                    nespravneObrazok.setVisibility(View.VISIBLE); // v prípade nesprávnej odpovede sa zobrazí obrázok, ktorý znázorňuje nesprávnu odpoveď
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            nespravneObrazok.setVisibility(View.INVISIBLE);
                            prveVozidlo.setEnabled(true);
                            druheVozidlo.setEnabled(true);
                            tretieVozidlo.setEnabled(true);
                        }
                    }, 1000);
                }
            }
        }

        if(pocetSpravnychKliknuti == 3) { // po troch správnych kliknutiach sa zobrazí tlačidlo na presun na ďaľšiu úlohu (križovatku)
            dalejButton.setVisibility(View.VISIBLE);
        }
    }

    public void nacitajDalsiu(View view) { // onClick metóda pre tlačidlo Ďalej
        pocetKrizovatiek++; // zvýši sa číslo počtu križovatiek
        pocetSpravnychKliknuti = 0; // počet správnych kliknutí sa vynuluje
        nacitajKrizovatku(); // zavolá sa metóda pre načítanie novej úlohy
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
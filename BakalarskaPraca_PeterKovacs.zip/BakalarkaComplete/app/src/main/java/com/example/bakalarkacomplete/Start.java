package com.example.bakalarkacomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Start extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        button = findViewById(R.id.startButton);

        button.setBackgroundColor(Color.rgb(185,85,255));
    }

    public void startAplikacie(View view) { // pomocou onClick metódy startAplikacie sa po stlačení tlačidla Štart vytvorí Intent a presunieme sa do Hlavného menu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
        Intent intent = new Intent(Start.this, HlavneMenu.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
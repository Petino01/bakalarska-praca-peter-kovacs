package com.example.bakalarkacomplete;

public class KrizovatkyDatabaza {
    public static String otazky[][] = {
            {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"}, {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"},
            {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"}, {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"},
            {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"}, {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"},
            {"Ktoré vozidlo prejde ako prvé?", "Ktoré vozidlo prejde ako druhé?", "Ktoré vozidlo prejde ako tretie?"}
    };

    public static int odpovede[][] = {
            {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista}, {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista}, {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista},
            {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista}, {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista}, {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista},
            {R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista}
    };

    public static int castiKrizovatky[][] = {
            {R.drawable.krizovatka_1a, R.drawable.krizovatka_1b, R.drawable.krizovatka_1c, R.drawable.krizovatka_1d}, {R.drawable.krizovatka_2a, R.drawable.krizovatka_2b, R.drawable.krizovatka_2c, R.drawable.krizovatka_2d},
            {R.drawable.krizovatka_3a, R.drawable.krizovatka_3b, R.drawable.krizovatka_3c, R.drawable.krizovatka_3d}, {R.drawable.krizovatka_4a, R.drawable.krizovatka_4b, R.drawable.krizovatka_4c, R.drawable.krizovatka_4d},
            {R.drawable.krizovatka_5a, R.drawable.krizovatka_5b, R.drawable.krizovatka_5c, R.drawable.krizovatka_5d}, {R.drawable.krizovatka_6a, R.drawable.krizovatka_6b, R.drawable.krizovatka_6c, R.drawable.krizovatka_6d},
            {R.drawable.krizovatka_7a, R.drawable.krizovatka_7b, R.drawable.krizovatka_7c, R.drawable.krizovatka_7d}
    };

    public static int prve[] = {
            R.drawable.zelene_auto, R.drawable.cyklista, R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista, R.drawable.cervene_auto, R.drawable.zelene_auto
    };

    public static int druhe[] = {
            R.drawable.cyklista, R.drawable.zelene_auto, R.drawable.zelene_auto, R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cyklista, R.drawable.cyklista
    };

    public static int tretie[] = {
            R.drawable.cervene_auto, R.drawable.cervene_auto, R.drawable.cyklista, R.drawable.cyklista, R.drawable.cervene_auto, R.drawable.zelene_auto, R.drawable.cervene_auto
    };
}

// databáza pre aktivitu Križovatky (Hra) ... obsahuje príslušné otázky pre každú križovatku, obrázky odpovedí, postupne meniace sa časti križovatiek a správne odpovede, ktoré vozidlo pôjde prvé, druhé a tretie

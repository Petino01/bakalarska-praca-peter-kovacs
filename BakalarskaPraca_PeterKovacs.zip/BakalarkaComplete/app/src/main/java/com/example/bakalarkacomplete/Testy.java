package com.example.bakalarkacomplete;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class Testy extends AppCompatActivity implements View.OnClickListener {

    TextView otazka, cisloOtazkyText;
    Button odpA, odpB, odpC, kontrolaB;
    Button odoslatB;
    ImageView obrazok;

    int odpoved;
    int skore;
    int cisloOtazky;
    String vybranaOdpoved;

    ArrayList<String> nespravneOdpovede;
    ArrayList<String> spravneOdpovede;
    ArrayList<String> otazky;
    ArrayList<Integer> obrazky;

    Integer[] poradie = {0, 1, 2}; // poradie zobrazenia odpovedí

    ArrayList<Integer> teoriaRandom, znackyRandom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testy);

        nespravneOdpovede = new ArrayList<String>();
        spravneOdpovede = new ArrayList<String>();
        otazky = new ArrayList<String>();
        obrazky = new ArrayList<Integer>();

        odpoved = 0;
        skore = 0;
        cisloOtazky = 0;
        vybranaOdpoved = "";

        otazka = findViewById(R.id.textOtazky);
        obrazok = findViewById(R.id.znackaObrazok);
        odpA = findViewById(R.id.odpA);
        odpB = findViewById(R.id.odpB);
        odpC = findViewById(R.id.odpC);
        kontrolaB = findViewById(R.id.odoslat);
        odoslatB = findViewById(R.id.dalej);

        cisloOtazkyText = findViewById(R.id.cisloOtazky);

        odoslatB.setBackgroundColor(Color.rgb(185,85,255));
        kontrolaB.setBackgroundColor(Color.rgb(185,85,255));

        odpA.setOnClickListener(this);
        odpB.setOnClickListener(this);
        odpC.setOnClickListener(this);
        kontrolaB.setOnClickListener(this);

        odoslatB.setVisibility(View.GONE);

        Random random = new Random();
        teoriaRandom = new ArrayList<Integer>();

        while(teoriaRandom.size() <= 5) { // vytvorí sa ArrayList random čísel a takto sa vyberie 5 náhodných teoretických otázok do testu
            int cislo = random.nextInt(26);

            if(!teoriaRandom.contains(cislo)) {
                teoriaRandom.add(cislo);
            }
        }

        Random random2 = new Random();
        znackyRandom = new ArrayList<Integer>();

        while(znackyRandom.size() <= 5) { // vytvorí sa ArrayList random čísel a takto sa vyberie 5 náhodných otázok, ktoré sa týkajú značiek
            int cislo = random2.nextInt(103);

            if(!znackyRandom.contains(cislo)) {
                znackyRandom.add(cislo);
            }
        }

        nacitajNovuOtazku(); // zavolá sa metóda pre načítanie prvej otázky
    }

    void nacitajNovuOtazku() {
        odpA.setBackgroundColor(Color.rgb(235,236,240));
        odpB.setBackgroundColor(Color.rgb(235,236,240));
        odpC.setBackgroundColor(Color.rgb(235,236,240));

        cisloOtazkyText.setText(cisloOtazky + 1 + "/10");

        odoslatB.setVisibility(View.GONE);
        kontrolaB.setVisibility(View.VISIBLE);

        Collections.shuffle(Arrays.asList(poradie)); // poradie, v ktorom sa odpovede zobrazia pri každej otázke sa zamieša pri načítaní každej novej otázky

        if(cisloOtazky <= 4) { // pokým počet otázok neprekročí hodnotu 4, budú sa načítavať teoretické otázky
            obrazok.setVisibility(View.INVISIBLE); // v tomto prípade nám je ImageView na nič a preto ho nastavíme na neviditeľný

            otazka.setText(OtazkyOdpovedeTest.otazkyTeoria[teoriaRandom.get(cisloOtazky)]); // načíta sa text otázky na danom indexe
            odpA.setText(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[0]]); // načíta sa prvá možnosť na danom indexe
            odpB.setText(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[1]]); // načíta sa druhá možnosť na danom indexe
            odpC.setText(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[2]]); // načíta sa tretia možnosť na danom indexe

            odpA.setEnabled(true);
            odpB.setEnabled(true);
            odpC.setEnabled(true); // povolí sa klikanie na tlačidlá s možnosťami

            otazky.add(OtazkyOdpovedeTest.otazkyTeoria[teoriaRandom.get(cisloOtazky)]); // znenie otázky sa vloží do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
        } else { // ak číslo otázky prekročí hodnotu 4 (čiže nasleduje 6. otázka), tak sa budú načítavať otázky zamerané na značky
            obrazok.setVisibility(View.VISIBLE); // v tomto prípade už ImageView budeme potrebovať a preto mu nastavíme viditeľnosť na viditeľný

            otazka.setText(OtazkyOdpovedeTest.otazkyZnacky[znackyRandom.get(cisloOtazky - 5)]); // načíta sa text otázky na danom indexe
            odpA.setText(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[0]]); // načíta sa prvá možnosť na danom indexe
            odpB.setText(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[1]]); // načíta sa druhá možnosť na danom indexe
            odpC.setText(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[2]]); // načíta sa tretia možnosť na danom indexe
            obrazok.setImageResource(OtazkyOdpovedeTest.obrazkyZnacky[znackyRandom.get(cisloOtazky - 5)]); // načíta sa obrázok značky na danom indexe

            odpA.setEnabled(true);
            odpB.setEnabled(true);
            odpC.setEnabled(true); // povolí sa klikanie na tlačidlá s možnosťami

            otazky.add(OtazkyOdpovedeTest.otazkyZnacky[znackyRandom.get(cisloOtazky - 5)]); // znenie otázky sa vloží do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
            obrazky.add(OtazkyOdpovedeTest.obrazkyZnacky[znackyRandom.get(cisloOtazky - 5)]); // odkaz na obrázok značky sa vloží do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
        }

        ukonciTest(); // na konci metódy sa zavolá metóda na kontrolu či sa nemá ukončiť test
    }

    @Override
    public void onClick(View view) {
        odpA.setBackgroundColor(Color.rgb(235,236,240));
        odpB.setBackgroundColor(Color.rgb(235,236,240));
        odpC.setBackgroundColor(Color.rgb(235,236,240));

        Button kliknutie = (Button) view; // nastavíme onClick na Button
        if(kliknutie.getId() == R.id.odoslat) { // ak sa klikne tlačidlo Potvrdiť vykoná sa nasledovné
            if(cisloOtazky <= 4) { // ak sa jedná o teoretickú otázku vykoná sa nasledovné
                if(vybranaOdpoved.equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa vybraná odpoveď rovná správnej odpovedi vykoná sa nasledovné
                    skore++; // zvýši sa skóre alebo inak povedané počet bodov
                    if(odpA.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa vybraná odpoveď nachádza v odpovedi A, vykoná sa nasledovné
                        odpA.setBackgroundColor(Color.GREEN); // zmení pozadie na zelenú farbu
                        spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)]); // pridá správnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                        nespravneOdpovede.add("-"); // pridá prázdnu nesprávnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                    }
                    if(odpB.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa vybraná odpoveď nachádza v odpovedi B, vykoná sa nasledovné
                        odpB.setBackgroundColor(Color.GREEN); // zmení pozadie na zelenú farbu
                        spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)]); // pridá správnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                        nespravneOdpovede.add("-"); // pridá prázdnu nesprávnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                    }
                    if(odpC.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa vybraná odpoveď nachádza v odpovedi C, vykoná sa nasledovné
                        odpC.setBackgroundColor(Color.GREEN); // zmení pozadie na zelenú farbu
                        spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)]); // pridá správnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                        nespravneOdpovede.add("-"); // pridá prázdnu nesprávnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                    }
                } else { // ak sa vybraná odpoveď nerovná správnej odpovedi vykoná sa nasledovné
                    if(vybranaOdpoved.equals(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[0]])) { // ak sa vybraná odpoveď nachádza v odpovedi A, vykoná sa nasledovné
                        odpA.setBackgroundColor(Color.RED); // zmení pozadie na červenú farbu
                        nespravneOdpovede.add(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[0]]); // pridá nesprávnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                    }
                    if(vybranaOdpoved.equals(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[1]])) { // ak sa vybraná odpoveď nachádza v odpovedi B, vykoná sa nasledovné
                        odpB.setBackgroundColor(Color.RED); // zmení pozadie na červenú farbu
                        nespravneOdpovede.add(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[1]]); // pridá nesprávnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                    }
                    if(vybranaOdpoved.equals(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[2]])) { // ak sa vybraná odpoveď nachádza v odpovedi C, vykoná sa nasledovné
                        odpC.setBackgroundColor(Color.RED); // zmení pozadie na červenú farbu
                        nespravneOdpovede.add(OtazkyOdpovedeTest.odpovedeTeoria[teoriaRandom.get(cisloOtazky)][poradie[2]]); // pridá nesprávnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                    }

                    if(!vybranaOdpoved.equals("")) { // následne ak sa vybraná odpoveď nerovná prázdnemu Stringu vykoná sa nasledovné
                        if(odpA.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa správna odpoveď nachádza v odpovedi A, vykoná sa nasledovné
                            odpA.setBackgroundColor(Color.GREEN); // zmení pozadie na zelenú farbu
                            spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)]); // pridá správnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                        }
                        if(odpB.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa správna odpoveď nachádza v odpovedi B, vykoná sa nasledovné
                            odpB.setBackgroundColor(Color.GREEN); // zmení pozadie na zelenú farbu
                            spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)]); // pridá správnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                        }
                        if(odpC.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)])) { // ak sa správna odpoveď nachádza v odpovedi C, vykoná sa nasledovné
                            odpC.setBackgroundColor(Color.GREEN); // zmení pozadie na zelenú farbu
                            spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeTeoria[teoriaRandom.get(cisloOtazky)]); // pridá správnu odpoveď do ArrayListu, ktorý budeme neskoršie posielať do prehľadu
                        }
                    } // pomocou tohto zabezpečíme zobrazenie nesprávnej odpovede červenou farbou a správnej odpovede zelenou farbou v prípade zvolenia nesprávnej odpovede
                }
            } else { // podobným spôsobom je riešená kontrola otázok týkajúcich sa značiek
                if (vybranaOdpoved.equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                    skore++;
                    if (odpA.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                        odpA.setBackgroundColor(Color.GREEN);
                        spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)]);
                        nespravneOdpovede.add("-");
                    }
                    if (odpB.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                        odpB.setBackgroundColor(Color.GREEN);
                        spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)]);
                        nespravneOdpovede.add("-");
                    }
                    if (odpC.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                        odpC.setBackgroundColor(Color.GREEN);
                        spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)]);
                        nespravneOdpovede.add("-");
                    }
                } else {
                    if (vybranaOdpoved.equals(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[0]])) {
                        odpA.setBackgroundColor(Color.RED);
                        nespravneOdpovede.add(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[0]]);
                    }
                    if (vybranaOdpoved.equals(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[1]])) {
                        odpB.setBackgroundColor(Color.RED);
                        nespravneOdpovede.add(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[1]]);
                    }
                    if (vybranaOdpoved.equals(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[2]])) {
                        odpC.setBackgroundColor(Color.RED);
                        nespravneOdpovede.add(OtazkyOdpovedeTest.odpovedeZnacky[znackyRandom.get(cisloOtazky - 5)][poradie[2]]);
                    }

                    if (!vybranaOdpoved.equals("")) {
                        if (odpA.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                            odpA.setBackgroundColor(Color.GREEN);
                            spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)]);
                        }
                        if (odpB.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                            odpB.setBackgroundColor(Color.GREEN);
                            spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)]);
                        }
                        if (odpC.getText().equals(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)])) {
                            odpC.setBackgroundColor(Color.GREEN);
                            spravneOdpovede.add(OtazkyOdpovedeTest.spravneOdpovedeZnacky[znackyRandom.get(cisloOtazky - 5)]);
                        }
                    }
                }
            }
        } else { // ak sa kliknutie nevykonalo na tlačidle Potvrdiť, uloží sa vybraná odpoveď používateľom z poskytnutých možností
            vybranaOdpoved = kliknutie.getText().toString();
            kliknutie.setBackgroundColor(Color.rgb(185,85,255));
        }

        if(!vybranaOdpoved.equals("") && kontrolaB.isPressed()) { // ak je zvolená odpoveď a vykoná sa stlačenie tlačidla Potvrdiť vykoná sa nasledovné
            odpA.setEnabled(false);
            odpB.setEnabled(false);
            odpC.setEnabled(false); // tlačidlá s možnosťami sa zablokujú a nie je možné na nich klikať
            kontrolaB.setVisibility(View.GONE); // tlačidlo pre kontrolu vybranej odpovedi zmizne
            odoslatB.setVisibility(View.VISIBLE); // tlačidlo na presun na ďaľšiu otázku sa zobrazí
        }
    }

    public void nacitajNovu(View view) { // pomocou onClick metódy nacitajNovu, sa po kliknutí na tlačidlo Ďalej vykoná nasledovné
        cisloOtazky++; // zvýši sa číslo otázky
        vybranaOdpoved = ""; // vybraná odpoveď sa nastaví na prázdny String
        nacitajNovuOtazku(); // zavolá sa metóda na načítanie ďaľšej otázky
    }

    void ukonciTest() { // metóda na kontrolu, či test má byť ukončený alebo nie
        if(cisloOtazky == 10) { // ak sa dosiahne počet otázok 10 vykoná sa nasledovné
            cisloOtazkyText.setVisibility(View.GONE);
            otazka.setVisibility(View.GONE);
            odpA.setVisibility(View.GONE);
            odpB.setVisibility(View.GONE);
            odpC.setVisibility(View.GONE);
            obrazok.setVisibility(View.GONE);
            kontrolaB.setVisibility(View.GONE); // všetky objekty v layoute sa nastavia na neviditeľné

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Testy.this, R.style.AlertDialogStyle); // zobrazí sa Alert Dialog s dvomi možnosťami
            alertDialogBuilder.setTitle("Ukončený test!")
                    .setMessage("Úspešne ste ukončili test a dostali ste " + skore + " z 10 možných bodov!") // v texte Alert Dialogu sa nachádza výsledný počet bodov používateľa
                    .setNeutralButton("Hlavné menu", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(Testy.this, HlavneMenu.class);
                            startActivity(intent);
                            finish(); // pri zvolení možnosti Hlavné menu sa pomocou Intentu presunieme do Hlavného menu a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                        }
                    })
                    .setPositiveButton("Prehľad", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(Testy.this, TestyPrehlad.class);
                            intent.putExtra("spravneOdpovede", spravneOdpovede);
                            intent.putExtra("nespravneOdpovede", nespravneOdpovede);
                            intent.putExtra("otazky", otazky);
                            intent.putExtra("obrazky", obrazky); // vložíme do intentu extra údaje, práve vyššie spomínané ArrayListy obsahujúce otázky, obrázky značiek, správne a nesprávne odpovede
                            startActivity(intent);
                            finish(); // pri zvolení možnosti Prehľad sa pomocou Intentu presunieme do Testy Prehľad a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.setCancelable(false);
            alertDialog.show();
            alertDialog.getButton(alertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(187,134,252));
            alertDialog.getButton(alertDialog.BUTTON_POSITIVE).setTextColor(Color.rgb(65,200,0));
        }
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
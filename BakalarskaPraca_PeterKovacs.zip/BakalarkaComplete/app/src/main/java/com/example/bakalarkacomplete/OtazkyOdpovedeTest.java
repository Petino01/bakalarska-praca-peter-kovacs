package com.example.bakalarkacomplete;

public class OtazkyOdpovedeTest {
    public static String otazkyTeoria[] = {
            "Chodec je účastník cestnej premávky pohybujúci sa", "Nemotorové vozidlo je napríklad", "Chodník je komunikácia alebo časť cesty určená pre", "Križovatka s riadenou premávkou je križovatka, ktorá je riadená", "Svetlo svietidla musí byť vpredu a vzadu viditeľné v noci na vzdialenosť",
            "Bicykel na prevádzku v cestnej premávke musí byť vybavený", "Výkon motorčeka bicykla s pomocným motorčekom nesmie presiahnuť", "Elektrický pomocný motorček na kolobežke neumožňuje vyvinúť rýchlosť vyššiu ako", "Na bicykli sa jazdí predovšetkým", "V skupine najmenej šiestich cyklistov môžu jazdiť",
            "Ak cestička pre chodcov a cyklistov má oddelené pruhy pre chodcov a cyklistov", "Cyklista mladší ako 15 rokov", "Dostatočný bočný odstup ostatných vozidiel od cyklistu je", "Kolobežku s pomocným motorčekom smie na ceste viesť", "Na jednomiestnej kolobežke s pomocným motorčekom",
            "Na bicyklovej ceste smie vodič jazdiť rýchlosťou", "Vodič smie vchádzať na železničné priecestie, ak", "Bicykel počas jazdy za zníženej viditeľnosti musí byť vybavený", "Kolobežka s pomocným motorčekom počas jazdy za zníženej viditeľnosti musí byť vybavená", "Vodiči kolobežiek s pomocným motorčekom",
            "Sú povinnosťou základnej výbavy bicykla v premávke odrazové sklá?", "Patrí do povinnej výbavy bicykla aj zvonček?", "Musí byť bicykel, ktorý vstupuje do premávky vybavený blatníkmi", "Križovatkou sa rozumie", "Ak policajt pri riadení premávky dáva pokyn kývaním ruky hore a dolu, znamená to",
            "Ak policajt pri riadení premávky dáva pokyn kývaním ruky doľava a doprava, znamená to"
    };

    public static String odpovedeTeoria[][] = {
            {"pešo, na kolobežke, skejtborde alebo tlačí bicykel, motocykel alebo kolobežku", "na motocykli", "v aute, autobuse alebo kamióne"}, {"auto", "kolobežka s pomocným motorčekom s maximálnou rýchlosťou 25 km/h", "bicykel s pomocným motorčekom s maximálnou rýchlosťou 35 km/h"}, {"chodcov", "vodičov motoriek", "autá"}, {"dopravnými zariadeniami (semaformi) alebo policajtom", "náhodným okoloidúcim", "účastníkmi cestnej premávky"}, {"najmenej 150 metrov", "najmenej 500 metrov", "najmenej 100 metrov"},
            {"dvomi účinnými brzdami", "nosičom batožín", "pomocným sedadlom na prepravu dieťaťa"}, {"0,25 kW", "25 kW", "2,5 kW"}, {"25 km/h", "35 km/h", "50 km/h"}, {"po cestičke pre cyklistov vpravo", "po ceste", "po chodníku"}, {"dvaja cyklisti vedľa seba", "len jednotlivo za sebou", "traja cyklisti vedľa seba"},
            {"sú chodci a cyklisti povinní použiť len pruh pre nich určený", "cyklisti môžu použiť aj pruh pre chodcov, ak tam žiadni nie sú", "cyklisti nesmú použiť danú cestičku na jazdu"}, {"je povinný počas jazdy na bicykli chrániť si hlavu riadne upevnenou prilbou", "nie je povinný počas jazdy na bicykli chrániť si hlavu riadne upevnenou prilbou", "si nesmie počas jazdy chrániť hlavu riadne upevnenou prilbou"}, {"minimálne 1 meter pri maximálnej rýchlosti 50 km/h", "minimálne 1,5 metra pri maximálnej rýchlosti 50 km/h", "minimálne 2 metre pri maximálnej rýchlosti 50 km/h"}, {"osoba staršia ako 15 rokov", "osoba staršia ako 18 rokov", "osoba staršia ako 10 rokov"}, {"nie je dovolená jazda viacerým osobám", "je dovolená jazda viacerým osobám", "nesmie chýbať nosič batožín"},
            {"najviac 30 km/h", "najviac 25 km/h", "najviac 50 km/h"}, {"bliká biele svetlo priecestného zabezpečovacieho zariadenia", "sa spúšťajú, ak sú spustené alebo ak sa zdvíhajú závory", "už vidieť alebo počuť prichádzajúci vlak"}, {"svietidlom svietiacim dopredu bielym svetlom", "svietidlom svietiacim dozadu modrým svetlom", "nosičom batožín"}, {"svietidlom svietiacim dopredu červeným svetlom", "svietidlom svietiacim dozadu červeným svetlom", "nosičom batožín"}, {"smú jazdiť len jednotlivo za sebou", "smú jazdiť dvaja vedľa seba", "smú jazdiť traja vedľa seba"},
            {"nie, iba v noci", "nie, stačia reflexné prvky na oblečení", "áno"}, {"áno", "nie", "iba za určitých podmienok"}, {"áno", "nie", "iba keď prší"}, {"miesto, v ktorom sa cesty pretínajú alebo spájajú", "mimoúrovňové kríženie cesty so železnicou", "miesto, v ktorom cesta mení smer"}, {"zastaviť vozidlo", "spomaliť jazdu", "zrýchliť jazdu"},
            {"zastaviť vozidlo", "spomaliť jazdu", "zrýchliť jazdu"}
    };

    public static String spravneOdpovedeTeoria[] = {
            "pešo, na kolobežke, skejtborde alebo tlačí bicykel, motocykel alebo kolobežku", "kolobežka s pomocným motorčekom s maximálnou rýchlosťou 25 km/h", "chodcov", "dopravnými zariadeniami (semaformi) alebo policajtom", "najmenej 150 metrov",
            "dvomi účinnými brzdami", "0,25 kW", "25 km/h", "po cestičke pre cyklistov vpravo", "dvaja cyklisti vedľa seba",
            "sú chodci a cyklisti povinní použiť len pruh pre nich určený", "je povinný počas jazdy na bicykli chrániť si hlavu riadne upevnenou prilbou", "minimálne 1 meter pri maximálnej rýchlosti 50 km/h", "osoba staršia ako 15 rokov", "nie je dovolená jazda viacerým osobám",
            "najviac 30 km/h", "bliká biele svetlo priecestného zabezpečovacieho zariadenia", "svietidlom svietiacim dopredu bielym svetlom", "svietidlom svietiacim dozadu červeným svetlom", "smú jazdiť len jednotlivo za sebou",
            "áno", "nie", "nie", "miesto, v ktorom sa cesty pretínajú alebo spájajú", "spomaliť jazdu",
            "zrýchliť jazdu"
    };

    public static String otazkyZnacky[] = {
            "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?",
            "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?",
            "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?", "Aká výstražná značka je na obrázku?",
            "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?",
            "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?",
            "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?",
            "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?",
            "Aká regulačná značka je na obrázku?", "Aká regulačná značka je na obrázku?",
            "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?",
            "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?",
            "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?",
            "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?",
            "Aká informačná značka je na obrázku?", "Aká informačná značka je na obrázku?",
            "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?",
            "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?", "Aká dodatková tabuľka je na obrázku?",
            "Aká vodorovná značka je na obrázku?", "Aká vodorovná značka je na obrázku?", "Aká vodorovná značka je na obrázku?", "Aká vodorovná značka je na obrázku?", "Aká vodorovná značka je na obrázku?",
            "Aká vodorovná značka je na obrázku?", "Aká vodorovná značka je na obrázku?",
            "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?",
            "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?",
            "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?", "Aký svetelný signál je na obrázku?",
            "Aký pokyn policajta je na obrázku?", "Aký pokyn policajta je na obrázku?", "Aký pokyn policajta je na obrázku?", "Aký pokyn policajta je na obrázku?", "Aký pokyn policajta je na obrázku?",
            "Aký pokyn policajta je na obrázku?",
            "Aký symbol je na obrázku?", "Aký symbol je na obrázku?", "Aký symbol je na obrázku?", "Aký symbol je na obrázku?", "Aký symbol je na obrázku?",
            "Aký symbol je na obrázku?", "Aký symbol je na obrázku?", "Aký symbol je na obrázku?"
    };

    public static int obrazkyZnacky[] = {
            R.drawable.vys01, R.drawable.vys02, R.drawable.vys03, R.drawable.vys04, R.drawable.vys05, R.drawable.vys06, R.drawable.vys07, R.drawable.vys08, R.drawable.vys09, R.drawable.vys10, R.drawable.vys11, R.drawable.vys12, R.drawable.vys13, R.drawable.vys14, R.drawable.vys15,

            R.drawable.reg01, R.drawable.reg02, R.drawable.reg03, R.drawable.reg04, R.drawable.reg05, R.drawable.reg06, R.drawable.reg07, R.drawable.reg08, R.drawable.reg09, R.drawable.reg10, R.drawable.reg11,
            R.drawable.reg12, R.drawable.reg13, R.drawable.reg14, R.drawable.reg15, R.drawable.reg16, R.drawable.reg17, R.drawable.reg18, R.drawable.reg19, R.drawable.reg20, R.drawable.reg21, R.drawable.reg22,

            R.drawable.inf01, R.drawable.inf02, R.drawable.inf03, R.drawable.inf04, R.drawable.inf05, R.drawable.inf06, R.drawable.inf07, R.drawable.inf08, R.drawable.inf09, R.drawable.inf10, R.drawable.inf11,
            R.drawable.inf12, R.drawable.inf13, R.drawable.inf14, R.drawable.inf15, R.drawable.inf16, R.drawable.inf17, R.drawable.inf18, R.drawable.inf19, R.drawable.inf20, R.drawable.inf21, R.drawable.inf22,

            R.drawable.dod01, R.drawable.dod02, R.drawable.dod03, R.drawable.dod04, R.drawable.dod05, R.drawable.dod06, R.drawable.dod07, R.drawable.dod08, R.drawable.dod09,

            R.drawable.vod01, R.drawable.vod02, R.drawable.vod03, R.drawable.vod04, R.drawable.vod05, R.drawable.vod06, R.drawable.vod07,

            R.drawable.sve01, R.drawable.sve02, R.drawable.sve03, R.drawable.sve04, R.drawable.sve05, R.drawable.sve06, R.drawable.sve07,
            R.drawable.sve08, R.drawable.sve09, R.drawable.sve10, R.drawable.sve11, R.drawable.sve12, R.drawable.sve13, R.drawable.sve14,

            R.drawable.pok01, R.drawable.pok02, R.drawable.pok03, R.drawable.pok04, R.drawable.pok05, R.drawable.pok06,

            R.drawable.sym01, R.drawable.sym02, R.drawable.sym03, R.drawable.sym04, R.drawable.sym05, R.drawable.sym06, R.drawable.sym07, R.drawable.sym08
    };

    public static String odpovedeZnacky[][] = {
            {"Nebezpečenstvo", "Výstražný kríž", "Križovatka"}, {"Zákruta", "Dvojitá zákruta", "Zúžená vozovka"}, {"Dvojitá zákruta", "Zákruta", "Zúžená vozovka"}, {"Klesanie", "Nebezpečenstvo", "Stúpanie"}, {"Stúpanie", "Klesanie", "Križovatka"},
            {"Zúžená vozovka", "Priecestie", "Križovatka"}, {"Svetelné signály", "Križovatka", "Nebezpečenstvo"}, {"Križovatka", "Zákruta", "Nebezpečenstvo"}, {"Chodci", "Cyklisti", "Deti"}, {"Deti", "Cyklisti", "Chodci"},
            {"Priechod pre chodcov", "Návesť pred priecestím", "Klesanie"}, {"Cyklisti", "Chodci", "Deti"}, {"Priecestie", "Návesť pred priecestím", "Stúpanie"}, {"Návesť pred priecestím", "Križovatka", "Priecestie"}, {"Výstražný kríž", "Nebezpečenstvo", "Križovatka"},

            {"Daj prednosť v jazde!", "Stoj, daj prednosť v jazde!", "Prednosť protiidúcich vozidiel"}, {"Stoj, daj prednosť v jazde!", "Daj prednosť v jazde!", "Prednosť protiidúcich vozidiel"}, {"Prednosť protiidúcich vozidiel", "Stoj, daj prednosť v jazde!", "Daj prednosť v jazde!"}, {"Prikázaný smer jazdy", "Prikázaný smer odbočenia", "Prikázaný smer obchádzania"}, {"Prikázaný smer odbočenia", "Prikázaný smer jazdy", "Prikázaný smer obchádzania"},
            {"Prikázaný smer obchádzania", "Prikázaný smer odbočenia", "Prikázaný smer jazdy"}, {"Kruhový objazd", "Oddelená cestička pre chodcov a cyklistov", "Zákaz otáčania"}, {"Zákaz odbočenia", "Zákaz otáčania", "Kruhový objazd"}, {"Zákaz otáčania", "Zákaz odbočenia", "Kruhový objazd"}, {"Cestička pre chodcov", "Spoločná cestička pre chodcov a cyklistov", "Oddelená cestička pre chodcov a cyklistov"},
            {"Cyklistická komunikácia", "Oddelená cestička pre chodcov a cyklistov", "Spoločná cestička pre chodcov a cyklistov"}, {"Spoločná cestička pre chodcov a cyklistov", "Oddelená cestička pre chodcov a cyklistov", "Cyklistická komunikácia"}, {"Oddelená cestička pre chodcov a cyklistov", "Spoločná cestička pre chodcov a cyklistov", "Cyklistická komunikácia"}, {"Zákaz vjazdu", "Zákaz vjazdu pre všetky vozidlá", "Zákaz vjazdu (vstupu) pre cyklistov"}, {"Zákaz vjazdu pre všetky vozidlá", "Zákaz vjazdu", "Zákaz vjazdu (vstupu) pre cyklistov"},
            {"Zákaz vjazdu (vstupu) pre cyklistov", "Zákaz vjazdu pre všetky vozidlá", "Zákaz vjazdu"}, {"Najvyššia dovolená rýchlosť", "Zóna najvyššej dovolenej rýchlosti", "Koniec zóny najvyššej dovolenej rýchlosti"}, {"Koniec viacerých zákazov", "Zákaz zastavenia", "Zákaz státia"}, {"Zóna najvyššej dovolenej rýchlosti", "Koniec zóny najvyššej dovolenej rýchlosti", "Najvyššia dovolená rýchlosť"}, {"Koniec zóny najvyššej dovolenej rýchlosti", "Zóna najvyššej dovolenej rýchlosti", "Najvyššia dovolená rýchlosť"},
            {"Zákaz zastavenia", "Zákaz státia", "Koniec viacerých zákazov"}, {"Zákaz státia", "Zákaz zastavenia", "Koniec viacerých zákazov"},

            {"Križovatka s prednosťou v jazde", "Hlavná cesta", "Koniec hlavnej cesty"}, {"Hlavná cesta", "Koniec hlavnej cesty", "Križovatka s prednosťou v jazde"}, {"Koniec hlavnej cesty", "Hlavná cesta", "Križovatka s prednosťou v jazde"}, {"Prednosť pred protiidúcimi vozidlami", "Jednosmerná cesta", "Slepá cesta"}, {"Obytná zóna", "Koniec obytnej zóny", "Pešia zóna"},
            {"Koniec obytnej zóny", "Obytná zóna", "Pešia zóna"}, {"Pešia zóna", "Koniec pešej zóny", "Školská zóna"}, {"Koniec pešej zóny", "Pešia zóna", "Školská zóna"}, {"Školská zóna", "Koniec školskej zóny", "Pešia zóna"}, {"Koniec školskej zóny", "Školská zóna", "Pešia zóna"},
            {"Jednosmerná cesta", "Slepá cesta", "Hlavná cesta"}, {"Bicyklová cesta", "Koniec bicyklovej cesty", "Pešia zóna"}, {"Koniec bicyklovej cesty", "Bicyklová cesta", "Pešia zóna"}, {"Priechod pre chodcov", "Priechod pre cyklistov", "Bicyklová cesta"}, {"Priechod pre cyklistov", "Priechod pre chodcov", "Bicyklová cesta"},
            {"Slepá cesta", "Jednosmerná cesta", "Koniec hlavnej cesty"}, {"Polícia", "Pešia zóna", "Obytná zóna"}, {"Cyklistický smerník tabuľový", "Cyklistický smerník šípový", "Cyklistický medzismerník"}, {"Cyklistický smerník šípový", "Cyklistický smerník tabuľový", "Cyklistický medzismerník"}, {"Cyklistický medzismerník", "Cyklistický smerník tabuľový", "Cyklistický smerník šípový"},
            {"Číslo cyklotrasy", "Bicyklová cesta", "Priechod pre cyklistov"}, {"Radenie do jazdných pruhov pred križovatkou", "Jednosmerná cesta", "Hlavná cesta"},

            {"Vzdialenosť", "Vzdialenosť k povinnému zastaveniu", "Smer platnosti"}, {"Smerová šípka", "Smer platnosti", "Vzdialenosť"}, {"Smer platnosti", "Smerová šípka", "Vzdialenosť"}, {"Priebeh hlavnej cesty", "Voľno", "Priečna jazda cyklistov"}, {"Vzdialenosť k povinnému zastaveniu", "Vzdialenosť", "Smerová šípka"},
            {"Priečna jazda električky", "Priečna jazda cyklistov", "Obojsmerná jazda cyklistov"}, {"Priečna jazda cyklistov", "Priečna jazda električky", "Obojsmerná jazda cyklistov"}, {"Obojsmerná jazda cyklistov", "Priečna jazda cyklistov", "Smerová šípka"}, {"Voľno", "Smerová šípka", "Smer platnosti"},

            {"STOP čiara", "Čakacia čiara", "Koridor pre cyklistov"}, {"Čakacia čiara", "STOP čiara", "Koridor pre cyklistov"}, {"Priechod pre chodcov", "Priechod pre cyklistov", "Koridor pre cyklistov"}, {"Miesto na prechádzanie", "Čakacia čiara", "STOP čiara"}, {"Priechod pre cyklistov", "Priechod pre chodcov", "Koridor pre cyklistov"},
            {"Smerové šípky", "Čakacia čiara", "Priechod pre chodcov"}, {"Koridor pre cyklistov", "Priechod pre cyklistov", "Priechod pre chodcov"},

            {"„Stoj“ - signál červenej farby v tvare plného kruhu", "„Stoj“ - signál červenej farby so symbolom šípky", "„Stoj“ - signál červenej farby v tvare chodca a bicykla"}, {"„Čakaj“ - signál žltej farby v tvare plného kruhu", "„Čakaj“ - signál žltej farby so symbolom šípky", "„Čakaj“ - signál žltej farby so symbolom šípok"}, {"„Voľno“ - signál zelenej farby v tvare plného kruhu", "„Voľno“ - signál v tvare zelených šípok", "„Voľno“ - signál pre cyklistov zelenej farby v tvare bicykla"}, {"„Stoj“ - signál červenej farby so symbolom šípky", "„Stoj“ - signál červenej farby v tvare chodca a bicykla", "„Stoj“ - signál pre cyklistov červenej farby v tvare bicykla"}, {"„Čakaj“ - signál žltej farby so symbolom šípky", "„Čakaj“ - signál pre cyklistov žltej farby v tvare bicykla", "„Čakaj“ - signál žltej farby so symbolom šípok"},
            {"„Voľno“ - signál v tvare zelenej šípky", "„Voľno“ - signál zelenej farby v tvare plného kruhu", "„Voľno“ - signál pre cyklistov zelenej farby v tvare bicykla"}, {"„Stoj“ - signál červenej farby so symbolom šípok", "„Stoj“ - signál červenej farby v tvare plného kruhu", "„Stoj“ - signál červenej farby v tvare chodca a bicykla"}, {"„Čakaj“ - signál žltej farby so symbolom šípok", "„Čakaj“ - signál žltej farby so symbolom šípky", "„Čakaj“ - signál pre cyklistov žltej farby v tvare bicykla"}, {"„Voľno“ - signál v tvare zelených šípok", "„Voľno“ - signál zelenej farby v tvare chodca a bicykla", "„Voľno“ - signál zelenej farby v tvare plného kruhu"}, {"„Stoj“ - signál pre cyklistov červenej farby v tvare bicykla", "„Stoj“ - signál červenej farby v tvare plného kruhu", "„Stoj“ - signál červenej farby v tvare chodca a bicykla"},
            {"„Čakaj“ - signál pre cyklistov žltej farby v tvare bicykla", "„Čakaj“ - signál žltej farby so symbolom šípok", "„Čakaj“ - signál žltej farby v tvare plného kruhu"}, {"„Voľno“ - signál pre cyklistov zelenej farby v tvare bicykla", "„Voľno“ - signál zelenej farby v tvare chodca a bicykla", "„Voľno“ - signál v tvare zelených šípok"}, {"„Stoj“ - signál červenej farby v tvare chodca a bicykla", "„Stoj“ - signál červenej farby v tvare plného kruhu", "„Stoj“ - signál červenej farby so symbolom šípky"}, {"„Voľno“ - signál zelenej farby v tvare chodca a bicykla", "„Voľno“ - signál v tvare zelených šípok", "„Voľno“ - signál zelenej farby v tvare plného kruhu"},

            {"Pokyn - „Stoj“", "Pokyn - „Stoj“ a „Voľno“", "Pokyn - „Čakaj“"}, {"Pokyn - „Čakaj“", "Pokyn - „Stoj“", "Pokyn - „Stoj“ a „Voľno“"}, {"Pokyn - „Voľno“", "Pokyn - „Stoj“ a „Voľno“", "Pokyn - „Stoj“"}, {"Pokyn - „Stoj“ a „Voľno“", "Pokyn - „Voľno“", "Pokyn - „Stoj“"}, {"Pokyn - Zrýchliť jazdu!", "Pokyn - Spomaliť jazdu!", "Pokyn - „Stoj“"},
            {"Pokyn - Spomaliť jazdu!", "Pokyn - Zrýchliť jazdu!", "Pokyn - „Stoj“"},

            {"Bicykle", "Elektrobicykle", "Malé elektrické vozidlá"}, {"Chodci", "Deti", "Malé elektrické vozidlá"}, {"Deti", "Chodci", "Malé elektrické vozidlá"}, {"Elektrobicykle", "Bicykle", "Malé elektrické vozidlá"}, {"Malé elektrické vozidlá", "Bicykle", "Elektrobicykle"},
            {"Osoby pohybujúce sa na korčuliach, skejtborde, kolobežke alebo na obdobnom športovom vybavení", "Elektrobicykle", "Chodci"}, {"Nemocnica", "Prvá pomoc", "Deti"}, {"Prvá pomoc", "Nemocnica", "Deti"}
    };

    public static String spravneOdpovedeZnacky[] = {
            "Nebezpečenstvo", "Zákruta", "Dvojitá zákruta", "Klesanie", "Stúpanie", "Zúžená vozovka", "Svetelné signály", "Križovatka", "Chodci", "Deti", "Priechod pre chodcov", "Cyklisti", "Priecestie", "Návesť pred priecestím", "Výstražný kríž",

            "Daj prednosť v jazde!", "Stoj, daj prednosť v jazde!", "Prednosť protiidúcich vozidiel", "Prikázaný smer jazdy", "Prikázaný smer odbočenia", "Prikázaný smer obchádzania", "Kruhový objazd", "Zákaz odbočenia", "Zákaz otáčania",
            "Cestička pre chodcov", "Cyklistická komunikácia", "Spoločná cestička pre chodcov a cyklistov", "Oddelená cestička pre chodcov a cyklistov", "Zákaz vjazdu", "Zákaz vjazdu pre všetky vozidlá", "Zákaz vjazdu (vstupu) pre cyklistov",
            "Najvyššia dovolená rýchlosť", "Koniec viacerých zákazov", "Zóna najvyššej dovolenej rýchlosti", "Koniec zóny najvyššej dovolenej rýchlosti", "Zákaz zastavenia", "Zákaz státia",

            "Križovatka s prednosťou v jazde", "Hlavná cesta", "Koniec hlavnej cesty", "Prednosť pred protiidúcimi vozidlami", "Obytná zóna", "Koniec obytnej zóny", "Pešia zóna", "Koniec pešej zóny", "Školská zóna", "Koniec školskej zóny",
            "Jednosmerná cesta", "Bicyklová cesta", "Koniec bicyklovej cesty", "Priechod pre chodcov", "Priechod pre cyklistov", "Slepá cesta", "Polícia", "Cyklistický smerník tabuľový", "Cyklistický smerník šípový",
            "Cyklistický medzismerník", "Číslo cyklotrasy", "Radenie do jazdných pruhov pred križovatkou",

            "Vzdialenosť", "Smerová šípka", "Smer platnosti", "Priebeh hlavnej cesty", "Vzdialenosť k povinnému zastaveniu", "Priečna jazda električky", "Priečna jazda cyklistov", "Obojsmerná jazda cyklistov", "Voľno",

            "STOP čiara", "Čakacia čiara", "Priechod pre chodcov", "Miesto na prechádzanie", "Priechod pre cyklistov", "Smerové šípky", "Koridor pre cyklistov",

            "„Stoj“ - signál červenej farby v tvare plného kruhu", "„Čakaj“ - signál žltej farby v tvare plného kruhu", "„Voľno“ - signál zelenej farby v tvare plného kruhu", "„Stoj“ - signál červenej farby so symbolom šípky",
            "„Čakaj“ - signál žltej farby so symbolom šípky", "„Voľno“ - signál v tvare zelenej šípky", "„Stoj“ - signál červenej farby so symbolom šípok", "„Čakaj“ - signál žltej farby so symbolom šípok",
            "„Voľno“ - signál v tvare zelených šípok", "„Stoj“ - signál pre cyklistov červenej farby v tvare bicykla", "„Čakaj“ - signál pre cyklistov žltej farby v tvare bicykla", "„Voľno“ - signál pre cyklistov zelenej farby v tvare bicykla",
            "„Stoj“ - signál červenej farby v tvare chodca a bicykla", "„Voľno“ - signál zelenej farby v tvare chodca a bicykla",

            "Pokyn - „Stoj“", "Pokyn - „Čakaj“", "Pokyn - „Voľno“", "Pokyn - „Stoj“ a „Voľno“", "Pokyn - Zrýchliť jazdu!", "Pokyn - Spomaliť jazdu!",

            "Bicykle", "Chodci", "Deti", "Elektrobicykle", "Malé elektrické vozidlá", "Osoby pohybujúce sa na korčuliach, skejtborde, kolobežke alebo na obdobnom športovom vybavení", "Nemocnica", "Prvá pomoc"
    };
}

// databáza pre aktivitu Testy ... obsahuje otázky z teórie, odpovede k daným otázkam, správnu odpoveď ... otázky k značkám, obrázky značiek, odpovede k daným otázkam, správnu odpoveď

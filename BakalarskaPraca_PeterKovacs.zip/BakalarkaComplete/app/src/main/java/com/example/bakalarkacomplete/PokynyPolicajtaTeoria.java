package com.example.bakalarkacomplete;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityPokynyPolicajtaTeoriaBinding;

public class PokynyPolicajtaTeoria extends DrawerTeoriaActivity {

    ActivityPokynyPolicajtaTeoriaBinding activityPokynyPolicajtaTeoriaBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityPokynyPolicajtaTeoriaBinding = ActivityPokynyPolicajtaTeoriaBinding.inflate(getLayoutInflater());
        setContentView(activityPokynyPolicajtaTeoriaBinding.getRoot());

        int[] texty = {R.id.prvyText, R.id.druhyText, R.id.tretiText, R.id.stvrtyText, R.id.piatyText, R.id.siestyText}; // pole intov s odkazmi na TextView texty v layoute

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            for(int id: texty) { // pomocou for cyklov priradíme všetkým textom príslušnú veľkosť pre danú veľkosť obrazovky
                TextView text = (TextView) findViewById(id);
                text.setTextSize(18);
            }
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(21);
            }
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(24);
            }
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(27);
            }
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(30);
            }
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(33);
            }
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            for(int id: texty) {
                TextView text = (TextView) findViewById(id);
                text.setTextSize(36);
            }
        }

        getSupportActionBar().setTitle("Pokyny policajta");
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
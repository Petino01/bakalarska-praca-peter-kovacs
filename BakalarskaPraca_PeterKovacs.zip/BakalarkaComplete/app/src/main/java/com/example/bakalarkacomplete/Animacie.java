package com.example.bakalarkacomplete;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import com.example.bakalarkacomplete.databinding.ActivityAnimacieBinding;

public class Animacie extends DrawerActivity {

    ActivityAnimacieBinding activityAnimacieBinding;

    TextView popis;
    VideoView videoView;
    ImageView playTlacitko, sipkaDolava, sipkaDoprava;

    int cisloAnimacie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityAnimacieBinding = ActivityAnimacieBinding.inflate(getLayoutInflater());
        setContentView(activityAnimacieBinding.getRoot());

        getSupportActionBar().setTitle("Animácie");

        cisloAnimacie = 0;

        popis = findViewById(R.id.textAnimacia);
        videoView = findViewById(R.id.animaciaPlayer);

        popis.setMovementMethod(new ScrollingMovementMethod()); // zabezpečenie scrollovania textu v TextView

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            popis.setTextSize(18);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            popis.setTextSize(21);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            popis.setTextSize(24);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            popis.setTextSize(27);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            popis.setTextSize(30);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            popis.setTextSize(33);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            popis.setTextSize(36);
        }

        playTlacitko = findViewById(R.id.tlacitkoSpusti);
        sipkaDolava = findViewById(R.id.sipkaDolava);
        sipkaDoprava = findViewById(R.id.sipkaDoprava);

        popis.setText(AnimacieDatabaza.popis[0]);

        String videoCesta = "android.resource://" + getPackageName() + "/" + AnimacieDatabaza.animacie[0];
        Uri uri = Uri.parse(videoCesta);
        videoView.setVideoURI(uri);
        videoView.seekTo(1);

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                videoView.seekTo(1);
                playTlacitko.setImageResource(R.drawable.play_icon); // po prehraní videa sa video nastaví na prvý frame a tlačidlo sa zmení na play icon
            }
        });
    }

    public void dolavaPosun(View view) { // jednoduché zabezpečenie fungovania šípky doľava
        if(cisloAnimacie > 0) { // ak je animácia v poradí minimálne druhá, odpočíta sa 1 a zobrazí sa animácia o jednu pozíciu dozadu v databáze
            cisloAnimacie = cisloAnimacie - 1;
        } else {
            cisloAnimacie = AnimacieDatabaza.popis.length - 1; // ak náhodou animácia je prvá v poradí, preskočí sa na poslednú
        }
        zmenaVidea(cisloAnimacie); // zavolanie metódy pre zmenu animácie
    }

    public void dopravaPosun(View view) { // podobný spôsob ako pri posune doľava
        if(cisloAnimacie < AnimacieDatabaza.popis.length - 1) {
            cisloAnimacie = cisloAnimacie + 1;
        } else {
            cisloAnimacie = 0;
        }
        zmenaVidea(cisloAnimacie);
    }

    public void zmenaVidea(int cislo) {
        String videoCesta = "android.resource://" + getPackageName() + "/" + AnimacieDatabaza.animacie[cislo];
        Uri uri = Uri.parse(videoCesta);
        videoView.setVideoURI(uri); // nastavenie nového videa
        videoView.seekTo(1); // nastavenie na prvý frame
        videoView.pause();
        playTlacitko.setImageResource(R.drawable.play_icon);

        popis.setText(AnimacieDatabaza.popis[cislo]);
        popis.scrollTo(0,0); // tento riadok kódu zabezpečí, aby text v TextView bol vyscrollovaný úplne navrch
    }

    public void spustenieVidea(View view) { // metóda pre zmenu ikonky medzi play a pause ... spustenie a pauznutie videa
        if(!videoView.isPlaying()) {
            videoView.start();
            playTlacitko.setImageResource(R.drawable.pause_icon);
        } else {
            videoView.pause();
            playTlacitko.setImageResource(R.drawable.play_icon);
        }
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}
package com.example.bakalarkacomplete;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.bakalarkacomplete.databinding.ActivityPribehBinding;

public class Pribeh extends DrawerActivity {

    ActivityPribehBinding activityPribehBinding;

    Button startButton;

    TextView uvod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityPribehBinding = ActivityPribehBinding.inflate(getLayoutInflater());
        setContentView(activityPribehBinding.getRoot());

        startButton = findViewById(R.id.startButton);

        startButton.setBackgroundColor(Color.rgb(185,85,255));

        uvod = findViewById(R.id.uvodnyText);

        uvod.setMovementMethod(new ScrollingMovementMethod()); // zabezpečenie scrollovania textu v TextView

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        float yInches = metrics.heightPixels/metrics.ydpi;
        float xInches = metrics.widthPixels/metrics.xdpi;
        double diagonalInches = Math.sqrt(xInches * xInches + yInches * yInches); // vzorec pre výpočet počtu palcov displeja daného zariadenia

        if(diagonalInches >= 3.5 && diagonalInches < 4.5) { // priradenie rôznych veľkostí textu pre rôzne veľkosti obrazoviek -- od 3,5 do 10,5 palcu
            uvod.setTextSize(18);
        } else if(diagonalInches >= 4.5 && diagonalInches < 5.5) {
            uvod.setTextSize(21);
        } else if(diagonalInches >= 5.5 && diagonalInches < 6.5) {
            uvod.setTextSize(24);
        } else if(diagonalInches >= 6.5 && diagonalInches < 7.5) {
            uvod.setTextSize(27);
        } else if(diagonalInches >= 7.5 && diagonalInches < 8.5) {
            uvod.setTextSize(30);
        } else if(diagonalInches >= 8.5 && diagonalInches < 9.5) {
            uvod.setTextSize(33);
        } else if(diagonalInches >= 9.5 && diagonalInches < 10.5) {
            uvod.setTextSize(36);
        }

        getSupportActionBar().setTitle("Príbeh");
    }

    public void spustiPribeh(View view) { // pomocou onClick metódy spustiPribeh sa po kliknutí na dané tlačidlo spustí aktivita PribehTest a následne sa aktuálna aktivita ukončí pomocou príkazu finish()
        Intent intent = new Intent(Pribeh.this, PribehTest.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() { // zabezpečenie, aby sa po stlačení tlačidla späť na telefóne nič nestalo a používateľ zostane v príslušnej aktivite

    }
}